import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, Star, Zap, Heart } from 'lucide-react';
import { useCart } from '../services/cartContext';

/* ── Renders 5 stars, supports half-stars at 0.5 granularity ── */
const StarRating = ({ rating }) => {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => {
        const filled = rating >= star;
        const half = !filled && rating >= star - 0.5;
        return (
          <span key={star} className="relative inline-block w-3.5 h-3.5">
            <Star
              size={14}
              className="text-gray-200 fill-gray-200 absolute inset-0"
            />
            <span
              className="absolute inset-0 overflow-hidden"
              style={{ width: filled ? '100%' : half ? '50%' : '0%' }}
            >
              <Star size={14} className="text-amber-400 fill-amber-400" />
            </span>
          </span>
        );
      })}
    </div>
  );
};

/* ── Badge pill colors ── */
const badgeStyles = {
  'Best Seller': 'bg-indigo-100 text-indigo-700',
  'Top Rated': 'bg-emerald-100 text-emerald-700',
  Sale: 'bg-rose-100 text-rose-600',
  'New': 'bg-violet-100 text-violet-700',
};

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();
  const navigate = useNavigate();
  const [wishlisted, setWishlisted] = useState(false);
  const [addedFeedback, setAddedFeedback] = useState(false);

  const discount =
    product.originalPrice
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : null;

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
    setAddedFeedback(true);
    setTimeout(() => setAddedFeedback(false), 1500);
  };

  const handleBuyNow = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
    navigate('/checkout');
  };

  const handleWishlist = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setWishlisted((w) => !w);
  };

  return (
    <Link
      to={`/product/${product.id || product._id}`}
      className="group relative flex flex-col bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
    >
      {/* ── Image area ── */}
      <div className="relative overflow-hidden bg-gray-50 aspect-[4/3]">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Gradient overlay on hover */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Badge */}
        {product.badge && (
          <span
            className={`absolute top-3 left-3 text-[11px] font-bold px-2.5 py-1 rounded-full ${badgeStyles[product.badge] ?? 'bg-gray-100 text-gray-600'
              }`}
          >
            {product.badge}
          </span>
        )}

        {/* Discount % */}
        {discount && (
          <span className="absolute top-3 right-3 bg-rose-500 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full">
            -{discount}%
          </span>
        )}

        {/* Low stock warning */}
        {(product.stock || product.countInStock) < 10 && (product.stock || product.countInStock) > 0 && !discount && (
          <span className="absolute top-3 right-3 bg-orange-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
            Only {product.stock || product.countInStock} left
          </span>
        )}

        {/* Wishlist button */}
        <button
          onClick={handleWishlist}
          aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
          className={`absolute bottom-3 right-3 w-8 h-8 rounded-full flex items-center justify-center shadow-md transition-all duration-200 ${wishlisted
            ? 'bg-rose-500 text-white scale-110'
            : 'bg-white/90 text-gray-400 hover:text-rose-500 hover:bg-white opacity-0 group-hover:opacity-100 translate-y-1 group-hover:translate-y-0'
            }`}
        >
          <Heart size={14} fill={wishlisted ? 'currentColor' : 'none'} />
        </button>
      </div>

      {/* ── Content area ── */}
      <div className="flex flex-col flex-1 p-4 gap-2">
        {/* Category */}
        <span className="text-[10px] font-semibold uppercase tracking-widest text-indigo-500">
          {product.category}
        </span>

        {/* Name */}
        <h3 className="text-sm font-semibold text-gray-900 line-clamp-1 group-hover:text-indigo-700 transition-colors duration-200">
          {product.name}
        </h3>

        {/* Description */}
        <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed">
          {product.description}
        </p>

        {/* Rating row */}
        <div className="flex items-center gap-2 mt-auto pt-1">
          <StarRating rating={product.rating} />
          <span className="text-xs font-semibold text-gray-700">{product.rating}</span>
          {product.reviewCount && (
            <span className="text-[11px] text-gray-400">({product.reviewCount})</span>
          )}
        </div>

        {/* Price row */}
        <div className="flex items-baseline gap-2">
          <span className="text-lg font-extrabold text-gray-900">
            ${product.price.toFixed(2)}
          </span>
          {product.originalPrice && (
            <span className="text-sm text-gray-400 line-through">
              ${product.originalPrice.toFixed(2)}
            </span>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex gap-2 mt-1">
          <button
            onClick={handleAddToCart}
            className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 border ${addedFeedback
              ? 'bg-emerald-500 text-white border-emerald-500'
              : 'bg-white text-indigo-600 border-indigo-200 hover:bg-indigo-50 hover:border-indigo-400'
              }`}
          >
            <ShoppingCart size={13} />
            {addedFeedback ? 'Added!' : 'Add to Cart'}
          </button>
          <button
            onClick={handleBuyNow}
            className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-indigo-600 text-white hover:bg-indigo-700 active:scale-95 transition-all duration-200 border border-indigo-600"
          >
            <Zap size={13} />
            Buy Now
          </button>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
