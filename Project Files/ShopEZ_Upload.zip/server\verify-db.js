import mongoose from 'mongoose';
import User from './models/User.js';
import Order from './models/Order.js';
import dotenv from 'dotenv';
dotenv.config();

const verifyDB = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        const user = await User.findOne({ email: 'shopper@test.com' });
        console.log('User found:', user ? 'Yes' : 'No');
        
        const orders = await Order.find().sort({ createdAt: -1 }).limit(1);
        console.log('Latest Order found:', orders.length > 0 ? 'Yes' : 'No');
        
        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
};

verifyDB();
