import { Users, Target, Heart } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About ShopEZ</h1>
          <p className="text-xl text-gray-600 max-w-3xl">
            We're on a mission to make online shopping simple, affordable, and enjoyable for everyone.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <div className="w-16 h-16 bg-gray-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <Target size={32} className="text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Our Mission</h3>
            <p className="text-gray-600">
              To provide high-quality products at competitive prices while delivering exceptional customer service.
            </p>
          </div>

          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <div className="w-16 h-16 bg-gray-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart size={32} className="text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Our Values</h3>
            <p className="text-gray-600">
              Customer satisfaction, integrity, and continuous improvement drive everything we do.
            </p>
          </div>

          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <div className="w-16 h-16 bg-gray-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users size={32} className="text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Our Team</h3>
            <p className="text-gray-600">
              A dedicated group of professionals passionate about creating the best shopping experience.
            </p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-8 md:p-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
          <div className="prose max-w-none text-gray-600 space-y-4">
            <p className="text-lg leading-relaxed">
              Founded in 2024, ShopEZ started with a simple idea: make online shopping easy, affordable, and accessible to everyone. What began as a small startup has grown into a trusted e-commerce platform serving thousands of customers worldwide.
            </p>
            <p className="text-lg leading-relaxed">
              We carefully curate our product selection to ensure quality and value. From the latest electronics to fashion essentials and lifestyle products, we offer a diverse range of items to meet your needs. Our commitment to customer satisfaction means we're constantly improving our service, expanding our product range, and finding new ways to make your shopping experience better.
            </p>
            <p className="text-lg leading-relaxed">
              At ShopEZ, we believe in transparency, fair pricing, and exceptional service. Every product we sell is backed by our quality guarantee, and our customer support team is always ready to help. We're not just selling products – we're building relationships and creating a community of satisfied shoppers.
            </p>
          </div>
        </div>

        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <p className="text-4xl font-bold text-gray-900 mb-2">10K+</p>
            <p className="text-gray-600">Happy Customers</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-gray-900 mb-2">500+</p>
            <p className="text-gray-600">Products</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-gray-900 mb-2">4.8</p>
            <p className="text-gray-600">Average Rating</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-gray-900 mb-2">24/7</p>
            <p className="text-gray-600">Support</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
