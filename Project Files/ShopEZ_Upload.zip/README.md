# ShopEZ E-Commerce Project

This project was built using the MERN stack (MongoDB, Express, React, Node.js).
To save space and allow for easy sharing, the `node_modules` folders have been excluded from this archive.

## How to Run This Project

To get this project running on your machine, please follow these steps:

### Prerequisites:
1. Make sure you have **Node.js** installed on your computer.
2. Make sure you have **MongoDB** installed and running (or a valid MongoDB URI in the `.env` file).

### Step 1: Install Backend Dependencies & Start Server
1. Open a terminal and navigate to the `server` folder.
2. Run `npm install` to download all the required backend dependencies.
3. Run `npm start` (or `node index.js`) to start the backend server.

### Step 2: Install Frontend Dependencies & Start Client
1. Open a new, separate terminal and navigate to the `client` folder.
2. Run `npm install` to download all the required frontend dependencies.
3. Run `npm run dev` to start the frontend application.

The application should now be fully functional!
