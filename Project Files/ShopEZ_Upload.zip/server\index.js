import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import productRoutes from './routes/productRoutes.js';
import userRoutes from './routes/userRoutes.js';
import cartRoutes from './routes/cartRoutes.js';
import orderRoutes from './routes/orderRoutes.js';
import adminRoutes from './routes/adminRoutes.js';

/* ─── Load environment variables ─── */
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

/* ══════════════════════════════════════
   MIDDLEWARE
══════════════════════════════════════ */
app.use(cors({
    origin: function (origin, callback) {
        // Allow strictly specific dev origins and 'null' for file:// double-click
        const allowedUrls = [
            process.env.CLIENT_URL || 'http://localhost:5173',
            'null'
        ];
        if (!origin || allowedUrls.includes(origin) || origin.startsWith('http://localhost:')) {
            callback(null, true);
        } else {
            callback(new Error('Not allowed by CORS'));
        }
    },
    credentials: true,
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/* ══════════════════════════════════════
   API ROUTES
══════════════════════════════════════ */
app.use('/api/products', productRoutes);
app.use('/api/users', userRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/admin', adminRoutes);

/* ══════════════════════════════════════
   ROUTES
══════════════════════════════════════ */

/** GET /api/health → Control Panel Health-check */
app.get('/api/health', (req, res) => {
    const dbState = mongoose.connection.readyState;
    const isConnected = dbState === 1;
    res.json({
        server: 'ok',
        database: isConnected ? 'connected' : 'disconnected'
    });
});

/** GET /  →  Health-check */
app.get('/', (req, res) => {
    res.json({
        message: 'ShopEZ API Running',
        status: 'ok',
        timestamp: new Date().toISOString(),
    });
});

/** 404 – catch-all for unknown routes */
app.use((req, res) => {
    res.status(404).json({ success: false, message: `Route ${req.method} ${req.originalUrl} not found` });
});

/** Global error handler */
app.use((err, req, res, next) => {   // eslint-disable-line no-unused-vars
    console.error('[Error]', err.stack);
    const statusCode = err.statusCode || 500;
    res.status(statusCode).json({
        success: false,
        message: err.message || 'Internal Server Error',
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
    });
});

/* ══════════════════════════════════════
   MONGODB  →  START SERVER
══════════════════════════════════════ */
const connectDB = async () => {
    try {
        const conn = await mongoose.connect(process.env.MONGO_URI);
        console.log(`✅ MongoDB connected: ${conn.connection.host}`);
    } catch (err) {
        console.error('❌ MongoDB connection failed:', err.message);
        process.exit(1); // Exit process on DB failure
    }
};

const startServer = async () => {
    await connectDB();

    app.listen(PORT, () => {
        console.log(`🚀 ShopEZ API running on http://localhost:${PORT}`);
        console.log(`   Environment : ${process.env.NODE_ENV || 'development'}`);
    });
};

startServer();
