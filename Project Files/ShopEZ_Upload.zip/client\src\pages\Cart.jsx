import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  ArrowRight,
  Tag,
  Truck,
  ShieldCheck,
  RefreshCw,
  ChevronRight,
  X,
} from 'lucide-react';
import { useCart } from '../services/cartContext';

/* ─── Fallback seed items so the page always looks great in demo ─── */
const SEED_ITEMS = [
  {
    id: 1,
    name: 'Wireless Headphones Pro',
    category: 'Electronics',
    price: 129.99,
    originalPrice: 179.99,
    image:
      'https://images.pexels.com/photos/3587478/pexels-photo-3587478.jpeg?auto=compress&cs=tinysrgb&w=400',
    quantity: 1,
    stock: 45,
  },
  {
    id: 2,
    name: 'Minimalist Watch',
    category: 'Fashion',
    price: 89.99,
    originalPrice: null,
    image:
      'https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?auto=compress&cs=tinysrgb&w=400',
    quantity: 2,
    stock: 30,
  },
  {
    id: 10,
    name: 'Premium Yoga Mat',
    category: 'Sports',
    price: 34.99,
    originalPrice: 49.99,
    image:
      'https://images.pexels.com/photos/3822668/pexels-photo-3822668.jpeg?auto=compress&cs=tinysrgb&w=400',
    quantity: 1,
    stock: 45,
  },
];

/* ─── Trust signals strip ─── */
const TRUST_ITEMS = [
  { Icon: Truck, label: 'Free shipping over $50' },
  { Icon: ShieldCheck, label: 'Secure checkout' },
  { Icon: RefreshCw, label: '30-day returns' },
];

/* ─── Progress bar toward free shipping ─── */
const FreeShippingBar = ({ subtotal, threshold = 50 }) => {
  const pct = Math.min((subtotal / threshold) * 100, 100);
  const remaining = Math.max(threshold - subtotal, 0);
  return (
    <div className="bg-indigo-50 rounded-xl p-3.5 mb-5">
      <div className="flex items-center gap-2 mb-2">
        <Truck size={14} className="text-indigo-600" />
        {remaining > 0 ? (
          <p className="text-xs text-indigo-700 font-medium">
            Add <span className="font-bold">${remaining.toFixed(2)}</span> more for free shipping!
          </p>
        ) : (
          <p className="text-xs text-emerald-700 font-bold">🎉 You've unlocked free shipping!</p>
        )}
      </div>
      <div className="h-1.5 bg-indigo-100 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
};

/* ─── Individual cart row ─── */
const CartItem = ({ item, onUpdate, onRemove }) => {
  const [removing, setRemoving] = useState(false);
  const discount = item.originalPrice
    ? Math.round(((item.originalPrice - item.price) / item.originalPrice) * 100)
    : null;

  const handleRemove = () => {
    setRemoving(true);
    setTimeout(() => onRemove(item.id), 300);
  };

  return (
    <div
      className={`group relative flex gap-4 p-4 sm:p-5 rounded-2xl bg-white border border-gray-100 shadow-sm hover:shadow-md transition-all duration-300 ${removing ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
        }`}
    >
      {/* Image */}
      <Link
        to={`/product/${item.id}`}
        className="flex-shrink-0 w-24 h-24 sm:w-28 sm:h-28 rounded-xl overflow-hidden bg-gray-50"
      >
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
      </Link>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-500">
              {item.category}
            </span>
            <Link
              to={`/product/${item.id}`}
              className="block font-semibold text-gray-900 hover:text-indigo-700 transition-colors text-sm sm:text-base truncate"
            >
              {item.name}
            </Link>
          </div>
          {/* Remove button */}
          <button
            onClick={handleRemove}
            aria-label="Remove item"
            className="flex-shrink-0 p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 transition-all duration-200"
          >
            <X size={16} />
          </button>
        </div>

        {/* Price */}
        <div className="flex items-baseline gap-2 mt-1">
          <span className="text-base sm:text-lg font-extrabold text-gray-900">
            ${item.price.toFixed(2)}
          </span>
          {item.originalPrice && (
            <span className="text-xs text-gray-400 line-through">
              ${item.originalPrice.toFixed(2)}
            </span>
          )}
          {discount && (
            <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded-full">
              -{discount}%
            </span>
          )}
        </div>

        {/* Qty + item total */}
        <div className="flex items-center justify-between mt-3">
          {/* Quantity stepper */}
          <div className="flex items-center bg-gray-50 border border-gray-200 rounded-xl overflow-hidden">
            <button
              onClick={() => onUpdate(item.id, item.quantity - 1)}
              disabled={item.quantity <= 1}
              aria-label="Decrease quantity"
              className="px-3 py-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <Minus size={14} />
            </button>
            <span className="w-9 text-center text-sm font-bold text-gray-900 select-none">
              {item.quantity}
            </span>
            <button
              onClick={() => onUpdate(item.id, item.quantity + 1)}
              disabled={item.quantity >= (item.stock ?? 99)}
              aria-label="Increase quantity"
              className="px-3 py-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <Plus size={14} />
            </button>
          </div>

          {/* Line total */}
          <span className="text-sm font-bold text-gray-900">
            ${(item.price * item.quantity).toFixed(2)}
          </span>
        </div>
      </div>
    </div>
  );
};

/* ════════════════════════════════════════
   CART PAGE
════════════════════════════════════════ */
const Cart = () => {
  const { cartItems, removeFromCart, updateQuantity, getCartTotal, clearCart } = useCart();
  const navigate = useNavigate();

  /* Use live cart if it has items, otherwise show seed demo items */
  const [demoItems, setDemoItems] = useState(SEED_ITEMS);
  const isLive = cartItems.length > 0;

  const items = isLive ? cartItems : demoItems;

  const handleUpdate = (id, qty) => {
    if (isLive) {
      updateQuantity(id, qty);
    } else {
      if (qty <= 0) {
        setDemoItems((prev) => prev.filter((i) => i.id !== id));
      } else {
        setDemoItems((prev) =>
          prev.map((i) => (i.id === id ? { ...i, quantity: qty } : i))
        );
      }
    }
  };

  const handleRemove = (id) => {
    if (isLive) {
      removeFromCart(id);
    } else {
      setDemoItems((prev) => prev.filter((i) => i.id !== id));
    }
  };

  /* ── Calculations ── */
  const subtotal = isLive
    ? getCartTotal()
    : items.reduce((s, i) => s + i.price * i.quantity, 0);
  const itemCount = items.reduce((s, i) => s + i.quantity, 0);
  const shippingThreshold = 50;
  const shipping = subtotal >= shippingThreshold ? 0 : 5.99;
  const taxRate = 0.08;
  const tax = subtotal * taxRate;
  const total = subtotal + shipping + tax;

  /* ── Coupon state ── */
  const [coupon, setCoupon] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const discountAmt = appliedCoupon ? subtotal * 0.1 : 0;

  const applyCoupon = () => {
    if (coupon.trim().toUpperCase() === 'SHOPEZ10') {
      setAppliedCoupon('SHOPEZ10');
      setCoupon('');
    }
  };

  /* ── Empty state ── */
  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50/30 flex items-center justify-center px-4">
        <div className="text-center max-w-sm">
          <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingBag size={40} className="text-indigo-400" />
          </div>
          <h2 className="text-2xl font-extrabold text-gray-900 mb-2">Your cart is empty</h2>
          <p className="text-gray-500 text-sm mb-8">
            Looks like you haven't added anything yet. Explore our collection and find something you love!
          </p>
          <Link
            to="/products"
            className="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 active:scale-95 transition-all duration-200 shadow-md shadow-indigo-200"
          >
            Browse Products
            <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">

        {/* ── Page Header ── */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center">
            <ShoppingBag size={20} className="text-indigo-600" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 leading-none">
              Shopping Cart
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {itemCount} {itemCount === 1 ? 'item' : 'items'}
              {!isLive && (
                <span className="ml-2 text-xs text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full font-medium">
                  Demo mode
                </span>
              )}
            </p>
          </div>
        </div>

        {/* ── Breadcrumb ── */}
        <nav className="flex items-center gap-1.5 text-xs text-gray-400 mb-8">
          <Link to="/" className="hover:text-gray-700 transition-colors">Home</Link>
          <ChevronRight size={12} />
          <Link to="/products" className="hover:text-gray-700 transition-colors">Products</Link>
          <ChevronRight size={12} />
          <span className="text-gray-600 font-medium">Cart</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-10 items-start">

          {/* ════════════════════════════════════════
              LEFT — Cart Items
          ════════════════════════════════════════ */}
          <div className="lg:col-span-2 space-y-4">
            {/* Column labels */}
            <div className="hidden sm:grid grid-cols-[1fr_auto] px-5 text-[11px] font-bold uppercase tracking-widest text-gray-400">
              <span>Product</span>
              <span>Total</span>
            </div>

            {items.map((item) => (
              <CartItem
                key={item.id}
                item={item}
                onUpdate={handleUpdate}
                onRemove={handleRemove}
              />
            ))}

            {/* Cart actions row */}
            <div className="flex items-center justify-between pt-2">
              <Link
                to="/products"
                className="inline-flex items-center gap-1.5 text-sm text-indigo-600 font-semibold hover:underline"
              >
                ← Continue Shopping
              </Link>
              <button
                onClick={() => {
                  if (isLive) clearCart();
                  else setDemoItems([]);
                }}
                className="inline-flex items-center gap-1.5 text-xs text-gray-400 hover:text-red-500 transition-colors"
              >
                <Trash2 size={13} />
                Clear cart
              </button>
            </div>

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-gray-100">
              {TRUST_ITEMS.map(({ Icon, label }) => (
                <div
                  key={label}
                  className="flex flex-col items-center gap-1.5 text-center p-3 rounded-xl bg-white border border-gray-100"
                >
                  <Icon size={18} className="text-indigo-500" />
                  <span className="text-[10px] text-gray-500 font-medium leading-tight">{label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* ════════════════════════════════════════
              RIGHT — Order Summary
          ════════════════════════════════════════ */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 sticky top-24">
              <h2 className="text-lg font-extrabold text-gray-900 mb-5">Order Summary</h2>

              {/* Free shipping progress */}
              <FreeShippingBar subtotal={subtotal} threshold={shippingThreshold} />

              {/* Line items */}
              <div className="space-y-3 text-sm mb-5">
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal ({itemCount} items)</span>
                  <span className="font-semibold text-gray-800">${subtotal.toFixed(2)}</span>
                </div>

                <div className="flex justify-between text-gray-600">
                  <span>Shipping</span>
                  <span className={`font-semibold ${shipping === 0 ? 'text-emerald-600' : 'text-gray-800'}`}>
                    {shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}
                  </span>
                </div>

                <div className="flex justify-between text-gray-600">
                  <span>Tax (8%)</span>
                  <span className="font-semibold text-gray-800">${tax.toFixed(2)}</span>
                </div>

                {appliedCoupon && (
                  <div className="flex justify-between text-emerald-600">
                    <span className="flex items-center gap-1">
                      <Tag size={12} />
                      Coupon ({appliedCoupon})
                    </span>
                    <span className="font-semibold">-${discountAmt.toFixed(2)}</span>
                  </div>
                )}
              </div>

              {/* Coupon input */}
              {!appliedCoupon && (
                <div className="mb-5">
                  <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
                    Coupon Code
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={coupon}
                      onChange={(e) => setCoupon(e.target.value.toUpperCase())}
                      onKeyDown={(e) => e.key === 'Enter' && applyCoupon()}
                      placeholder="e.g. SHOPEZ10"
                      className="flex-1 px-3 py-2 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:border-transparent transition-all"
                    />
                    <button
                      onClick={applyCoupon}
                      className="px-3 py-2 bg-indigo-50 text-indigo-700 text-sm font-semibold rounded-xl hover:bg-indigo-100 transition-colors border border-indigo-100"
                    >
                      Apply
                    </button>
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1">Try: <span className="font-mono font-semibold">SHOPEZ10</span> for 10% off</p>
                </div>
              )}

              {appliedCoupon && (
                <div className="flex items-center justify-between mb-5 px-3 py-2 bg-emerald-50 rounded-xl border border-emerald-100">
                  <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                    <Tag size={12} /> {appliedCoupon} applied
                  </span>
                  <button
                    onClick={() => setAppliedCoupon(null)}
                    className="text-emerald-500 hover:text-emerald-700"
                  >
                    <X size={14} />
                  </button>
                </div>
              )}

              {/* Divider + Total */}
              <div className="border-t border-dashed border-gray-200 pt-4 mb-5">
                <div className="flex justify-between items-baseline">
                  <span className="font-bold text-gray-900">Total</span>
                  <div className="text-right">
                    <span className="text-2xl font-extrabold text-gray-900">
                      ${(total - discountAmt).toFixed(2)}
                    </span>
                    <p className="text-[10px] text-gray-400">Incl. tax & shipping</p>
                  </div>
                </div>
              </div>

              {/* Checkout CTA */}
              <button
                onClick={() => navigate('/checkout')}
                className="w-full flex items-center justify-center gap-2 py-3.5 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 active:scale-95 transition-all duration-200 shadow-lg shadow-indigo-200"
              >
                Proceed to Checkout
                <ArrowRight size={16} />
              </button>

              {/* Payment icons */}
              <div className="mt-4 flex flex-col items-center gap-2">
                <p className="text-[10px] text-gray-400 font-medium">Secure payment via</p>
                <div className="flex items-center gap-3 opacity-50 grayscale">
                  {['VISA', 'MC', 'AMEX', 'PayPal'].map((brand) => (
                    <span
                      key={brand}
                      className="text-[10px] font-bold border border-gray-300 rounded px-1.5 py-0.5 text-gray-600"
                    >
                      {brand}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
