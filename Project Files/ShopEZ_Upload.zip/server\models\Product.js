import mongoose from 'mongoose';

const productSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: [true, 'Product name is required'],
            trim: true,
        },
        description: {
            type: String,
            trim: true,
        },
        price: {
            type: Number,
            required: [true, 'Product price is required'],
            min: [0, 'Price cannot be negative'],
        },
        category: {
            type: String,
            trim: true,
        },
        image: {
            type: String,
            trim: true,
        },
        rating: {
            type: Number,
            default: 0,
            min: 0,
            max: 5,
        },
        createdAt: {
            type: Date,
            default: Date.now,
        },
    },
    {
        // Adds updatedAt automatically in addition to the manual createdAt
        timestamps: { createdAt: false, updatedAt: 'updatedAt' },
    }
);

const Product = mongoose.model('Product', productSchema);

export default Product;
