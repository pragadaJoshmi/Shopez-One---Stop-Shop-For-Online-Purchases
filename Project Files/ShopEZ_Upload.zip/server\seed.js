import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import Product from './models/Product.js';

/* ─── Resolve __dirname for ES modules ─── */
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/* ─── Load .env from the same directory as this file ─── */
dotenv.config({ path: join(__dirname, '.env') });

/* ══════════════════════════════════════
   SAMPLE PRODUCTS
══════════════════════════════════════ */
const sampleProducts = [
    {
        name: 'Wireless Headphones Pro',
        description: 'Premium wireless headphones with active noise cancellation, 30-hour battery life, and Hi-Res audio support.',
        price: 129.99,
        category: 'Electronics',
        image: 'https://images.pexels.com/photos/3587478/pexels-photo-3587478.jpeg?auto=compress&cs=tinysrgb&w=800',
        rating: 4.5,
    },
    {
        name: 'Minimalist Leather Watch',
        description: 'Elegant minimalist watch with genuine leather strap, Japanese quartz movement, and sapphire crystal glass.',
        price: 89.99,
        category: 'Fashion',
        image: 'https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?auto=compress&cs=tinysrgb&w=800',
        rating: 4.7,
    },
    {
        name: 'Canvas Backpack',
        description: 'Durable canvas backpack with laptop compartment, water bottle pockets, and ergonomic padded straps.',
        price: 59.99,
        category: 'Fashion',
        image: 'https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg?auto=compress&cs=tinysrgb&w=800',
        rating: 4.6,
    },
    {
        name: 'Premium Yoga Mat',
        description: 'Non-slip premium yoga mat with alignment lines, extra thickness for joint support, and carrying strap.',
        price: 34.99,
        category: 'Sports',
        image: 'https://images.pexels.com/photos/3822668/pexels-photo-3822668.jpeg?auto=compress&cs=tinysrgb&w=800',
        rating: 4.6,
    },
    {
        name: 'Smart LED Desk Lamp',
        description: 'Touch-controlled LED desk lamp with adjustable brightness, color temperature modes, and USB charging port.',
        price: 44.99,
        category: 'Home',
        image: 'https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg?auto=compress&cs=tinysrgb&w=800',
        rating: 4.4,
    },
];

/* ══════════════════════════════════════
   SEED FUNCTION
══════════════════════════════════════ */
const seedDB = async () => {
    /* Guard: ensure MONGO_URI is set */
    if (!process.env.MONGO_URI) {
        console.error('❌ MONGO_URI is not defined in .env');
        process.exit(1);
    }

    console.log('⏳ Connecting to MongoDB...');
    console.log('   URI:', process.env.MONGO_URI);

    try {
        /* ─── Connect with a 10-second timeout ─── */
        await mongoose.connect(process.env.MONGO_URI, {
            serverSelectionTimeoutMS: 10000,
        });
        console.log('✅ MongoDB connected:', mongoose.connection.host);

        /* ─── Clear existing products ─── */
        const deleted = await Product.deleteMany({});
        console.log(`🗑️  Cleared ${deleted.deletedCount} existing product(s)`);

        /* ─── Insert new products ─── */
        const inserted = await Product.insertMany(sampleProducts);
        console.log(`\n🌱 Seeded ${inserted.length} products successfully:`);
        inserted.forEach((p) =>
            console.log(`   ✔ [${p.category}] ${p.name} — $${p.price}`)
        );

        console.log('\n✅ Database seeded successfully!');
    } catch (err) {
        console.error('\n❌ Seed failed!');
        console.error('   Reason:', err.message);
        if (err.name === 'MongoServerSelectionError') {
            console.error('   Make sure MongoDB is running on your machine.');
            console.error('   Tip: run "mongod" in a separate terminal, or start MongoDB Compass.');
        }
        process.exit(1);
    } finally {
        /* ─── Always close the connection ─── */
        if (mongoose.connection.readyState !== 0) {
            await mongoose.connection.close();
            console.log('🔌 MongoDB connection closed');
        }
    }
};

seedDB();
