import { useState, useEffect, useMemo } from 'react';
import {
  Search,
  SlidersHorizontal,
  ChevronDown,
  X,
  LayoutGrid,
  List,
  ArrowUpDown,
} from 'lucide-react';
import ProductCard from '../components/ProductCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { productService } from '../services/productService';

/* ── Category metadata ── */
const CATEGORIES = [
  { label: 'All', emoji: '🛍️' },
  { label: 'Electronics', emoji: '⚡' },
  { label: 'Fashion', emoji: '👗' },
  { label: 'Sports', emoji: '🏃' },
  { label: 'Home', emoji: '🏠' },
];

const SORT_OPTIONS = [
  { value: 'featured', label: 'Featured' },
  { value: 'price-low', label: 'Price: Low → High' },
  { value: 'price-high', label: 'Price: High → Low' },
  { value: 'rating', label: 'Highest Rated' },
  { value: 'newest', label: 'Newest First' },
];

const MAX_PRICE = 250;

/* ── Reusable range slider ── */
const PriceRangeSlider = ({ min, max, value, onChange }) => {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="relative pt-1">
      <input
        type="range"
        min={min}
        max={max}
        step={5}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
        style={{
          background: `linear-gradient(to right, #6366f1 0%, #6366f1 ${pct}%, #e5e7eb ${pct}%, #e5e7eb 100%)`,
        }}
      />
      <div className="flex justify-between mt-1.5">
        <span className="text-[11px] text-gray-400">${min}</span>
        <span className="text-[11px] font-semibold text-indigo-600">${value}</span>
        <span className="text-[11px] text-gray-400">${max}</span>
      </div>
    </div>
  );
};

const Products = () => {
  const [allProducts, setAllProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  /* Filters */
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [maxPrice, setMaxPrice] = useState(MAX_PRICE);
  const [sortBy, setSortBy] = useState('featured');

  /* UI state */
  const [gridCols, setGridCols] = useState(4); // 4 | 3 | 2  (desktop col options)
  const [filtersOpen, setFiltersOpen] = useState(false); // mobile drawer
  const [sortOpen, setSortOpen] = useState(false);

  /* Fetch products from backend API */
  useEffect(() => {
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const data = await productService.getAllProducts();
        setAllProducts(Array.isArray(data) ? data : []);
      } catch (err) {
        const msg =
          err?.response?.data?.message ||
          (err?.code === 'ERR_NETWORK'
            ? 'Cannot reach the server. Make sure the backend is running on http://localhost:5000.'
            : err?.message || 'Failed to load products. Please try again.');
        setError(msg);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  /* Derived filtered + sorted list */
  const filteredProducts = useMemo(() => {
    let list = [...allProducts];

    if (selectedCategory !== 'All') {
      list = list.filter((p) => p.category === selectedCategory);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q)
      );
    }
    list = list.filter((p) => p.price <= maxPrice);

    switch (sortBy) {
      case 'price-low':
        list.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        list.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        list.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
        list.sort((a, b) => b.id - a.id);
        break;
      default:
        list.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
    }

    return list;
  }, [allProducts, selectedCategory, search, maxPrice, sortBy]);

  const clearFilters = () => {
    setSearch('');
    setSelectedCategory('All');
    setMaxPrice(MAX_PRICE);
    setSortBy('featured');
  };

  const hasActiveFilters =
    search || selectedCategory !== 'All' || maxPrice < MAX_PRICE || sortBy !== 'featured';

  /* ── Grid col class map ── */
  const gridClass = {
    4: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4',
    3: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
    2: 'grid-cols-1 sm:grid-cols-2',
  }[gridCols];

  /* ── Loading state: full-screen spinner ── */
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50/30 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-full border-4 border-indigo-100 border-t-indigo-600 animate-spin" />
          <p className="text-sm font-medium text-gray-500">Loading products…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50/30">
      {/* ── Page Hero Header ── */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-indigo-500 mb-1">
                Our Collection
              </p>
              <h1 className="text-4xl font-extrabold text-gray-900 tracking-tight">
                All Products
              </h1>
              <p className="mt-1 text-gray-500 text-sm">
                Discover {allProducts.length}+ premium products curated just for you
              </p>
            </div>

            {/* Global Search Bar */}
            <div className="relative w-full md:w-80">
              <Search
                size={16}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400"
              />
              <input
                type="text"
                placeholder="Search products..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:border-transparent focus:bg-white transition-all duration-200"
              />
              {search && (
                <button
                  onClick={() => setSearch('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <X size={14} />
                </button>
              )}
            </div>
          </div>

          {/* ── Category Pills ── */}
          <div className="flex flex-wrap gap-2 mt-6">
            {CATEGORIES.map(({ label, emoji }) => (
              <button
                key={label}
                onClick={() => setSelectedCategory(label)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${selectedCategory === label
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
                  : 'bg-white text-gray-600 border border-gray-200 hover:border-indigo-300 hover:text-indigo-600'
                  }`}
              >
                <span>{emoji}</span>
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        {/* ── Error Banner ── */}
        {error && (
          <div className="mb-6 flex items-start gap-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-2xl px-5 py-4">
            <svg className="w-5 h-5 mt-0.5 flex-shrink-0 text-rose-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
            </svg>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold">Failed to load products</p>
              <p className="text-sm mt-0.5 opacity-80">{error}</p>
            </div>
            <button
              onClick={() => {
                setError(null);
                setLoading(true);
                productService.getAllProducts()
                  .then((data) => setAllProducts(Array.isArray(data) ? data : []))
                  .catch((err) => setError(err?.code === 'ERR_NETWORK'
                    ? 'Cannot reach the server. Make sure the backend is running on http://localhost:5000.'
                    : err?.message || 'Failed to load products.'))
                  .finally(() => setLoading(false));
              }}
              className="flex-shrink-0 text-xs font-semibold underline underline-offset-2 hover:opacity-70 transition-opacity"
            >
              Retry
            </button>
          </div>
        )}

        <div className="flex gap-8">
          {/* ════════════════════════════════════════
              LEFT SIDEBAR — Filters (desktop)
          ════════════════════════════════════════ */}
          <aside className="hidden lg:block w-60 flex-shrink-0">
            <div className="sticky top-24 space-y-6">
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-2">
                    <SlidersHorizontal size={16} className="text-indigo-600" />
                    <span className="font-semibold text-gray-900 text-sm">Filters</span>
                  </div>
                  {hasActiveFilters && (
                    <button
                      onClick={clearFilters}
                      className="text-xs text-indigo-600 font-medium hover:underline"
                    >
                      Clear all
                    </button>
                  )}
                </div>

                {/* Category filter */}
                <div className="mb-6">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
                    Category
                  </h3>
                  <div className="space-y-1">
                    {CATEGORIES.map(({ label, emoji }) => (
                      <button
                        key={label}
                        onClick={() => setSelectedCategory(label)}
                        className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all duration-150 ${selectedCategory === label
                          ? 'bg-indigo-50 text-indigo-700 font-semibold'
                          : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                          }`}
                      >
                        <span className="text-base leading-none">{emoji}</span>
                        {label}
                        {selectedCategory === label && (
                          <span className="ml-auto w-2 h-2 rounded-full bg-indigo-600" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Price range */}
                <div className="mb-6">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
                    Max Price
                  </h3>
                  <PriceRangeSlider
                    min={0}
                    max={MAX_PRICE}
                    value={maxPrice}
                    onChange={setMaxPrice}
                  />
                </div>

                {/* Sort */}
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
                    Sort By
                  </h3>
                  <div className="space-y-1">
                    {SORT_OPTIONS.map((opt) => (
                      <button
                        key={opt.value}
                        onClick={() => setSortBy(opt.value)}
                        className={`w-full text-left px-3 py-2 rounded-xl text-sm transition-all duration-150 ${sortBy === opt.value
                          ? 'bg-indigo-50 text-indigo-700 font-semibold'
                          : 'text-gray-600 hover:bg-gray-50'
                          }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* ════════════════════════════════════════
              MAIN CONTENT
          ════════════════════════════════════════ */}
          <main className="flex-1 min-w-0">
            {/* Toolbar row */}
            <div className="flex items-center justify-between mb-5 gap-3">
              <p className="text-sm text-gray-500">
                Showing{' '}
                <span className="font-semibold text-gray-800">{filteredProducts.length}</span>{' '}
                {filteredProducts.length === 1 ? 'product' : 'products'}
                {selectedCategory !== 'All' && (
                  <> in <span className="text-indigo-600 font-semibold">{selectedCategory}</span></>
                )}
              </p>

              <div className="flex items-center gap-2">
                {/* Mobile filter toggle */}
                <button
                  onClick={() => setFiltersOpen(true)}
                  className="lg:hidden flex items-center gap-1.5 px-3 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:border-indigo-300 hover:text-indigo-600 transition-colors"
                >
                  <SlidersHorizontal size={14} />
                  Filters
                  {hasActiveFilters && (
                    <span className="w-2 h-2 rounded-full bg-indigo-600" />
                  )}
                </button>

                {/* Mobile sort dropdown */}
                <div className="relative lg:hidden">
                  <button
                    onClick={() => setSortOpen((o) => !o)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:border-indigo-300 transition-colors"
                  >
                    <ArrowUpDown size={14} />
                    Sort
                    <ChevronDown size={12} className={`transition-transform ${sortOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {sortOpen && (
                    <div className="absolute right-0 top-full mt-1 w-44 bg-white border border-gray-100 rounded-xl shadow-lg z-30 py-1 overflow-hidden">
                      {SORT_OPTIONS.map((opt) => (
                        <button
                          key={opt.value}
                          onClick={() => { setSortBy(opt.value); setSortOpen(false); }}
                          className={`w-full text-left px-4 py-2.5 text-sm transition-colors ${sortBy === opt.value
                            ? 'bg-indigo-50 text-indigo-700 font-semibold'
                            : 'text-gray-700 hover:bg-gray-50'
                            }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Desktop grid-density toggler */}
                <div className="hidden lg:flex items-center gap-1 p-1 bg-gray-100 rounded-xl">
                  {[
                    { cols: 4, Icon: LayoutGrid },
                    { cols: 3, Icon: LayoutGrid },
                    { cols: 2, Icon: List },
                  ].map(({ cols, Icon }) => (
                    <button
                      key={cols}
                      onClick={() => setGridCols(cols)}
                      title={`${cols} columns`}
                      className={`p-1.5 rounded-lg transition-all duration-150 ${gridCols === cols
                        ? 'bg-white text-indigo-600 shadow-sm'
                        : 'text-gray-400 hover:text-gray-700'
                        }`}
                    >
                      <Icon size={15} />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Active filter chips */}
            {hasActiveFilters && (
              <div className="flex flex-wrap gap-2 mb-5">
                {selectedCategory !== 'All' && (
                  <span className="flex items-center gap-1 pl-3 pr-2 py-1 bg-indigo-50 text-indigo-700 text-xs font-medium rounded-full">
                    {selectedCategory}
                    <button onClick={() => setSelectedCategory('All')} className="hover:text-indigo-900">
                      <X size={12} />
                    </button>
                  </span>
                )}
                {maxPrice < MAX_PRICE && (
                  <span className="flex items-center gap-1 pl-3 pr-2 py-1 bg-indigo-50 text-indigo-700 text-xs font-medium rounded-full">
                    Under ${maxPrice}
                    <button onClick={() => setMaxPrice(MAX_PRICE)} className="hover:text-indigo-900">
                      <X size={12} />
                    </button>
                  </span>
                )}
                {search && (
                  <span className="flex items-center gap-1 pl-3 pr-2 py-1 bg-indigo-50 text-indigo-700 text-xs font-medium rounded-full">
                    "{search}"
                    <button onClick={() => setSearch('')} className="hover:text-indigo-900">
                      <X size={12} />
                    </button>
                  </span>
                )}
              </div>
            )}

            {/* Products grid / states */}
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <LoadingSpinner />
              </div>
            ) : filteredProducts.length > 0 ? (
              <div className={`grid ${gridClass} gap-5`}>
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-24 text-center">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">No products found</h3>
                <p className="text-gray-500 text-sm mb-6 max-w-xs">
                  Try adjusting your search or filters to find what you're looking for.
                </p>
                <button
                  onClick={clearFilters}
                  className="px-5 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl hover:bg-indigo-700 transition-colors"
                >
                  Clear All Filters
                </button>
              </div>
            )}
          </main>
        </div>
      </div>

      {/* ════════════════════════════════════════
          MOBILE FILTER DRAWER
      ════════════════════════════════════════ */}
      {filtersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            onClick={() => setFiltersOpen(false)}
          />
          {/* Panel */}
          <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl p-6 max-h-[85vh] overflow-y-auto animate-in slide-in-from-bottom duration-300">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-bold text-gray-900">Filters & Sort</h2>
              <button
                onClick={() => setFiltersOpen(false)}
                className="p-2 rounded-full hover:bg-gray-100 transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Category */}
            <div className="mb-6">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
                Category
              </h3>
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map(({ label, emoji }) => (
                  <button
                    key={label}
                    onClick={() => setSelectedCategory(label)}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-full text-sm font-medium transition-all ${selectedCategory === label
                      ? 'bg-indigo-600 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                  >
                    {emoji} {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Price range */}
            <div className="mb-6">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
                Max Price
              </h3>
              <PriceRangeSlider
                min={0}
                max={MAX_PRICE}
                value={maxPrice}
                onChange={setMaxPrice}
              />
            </div>

            {/* Sort */}
            <div className="mb-8">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
                Sort By
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {SORT_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => setSortBy(opt.value)}
                    className={`px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${sortBy === opt.value
                      ? 'bg-indigo-600 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={clearFilters}
                className="flex-1 py-3 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50 transition-colors"
              >
                Clear All
              </button>
              <button
                onClick={() => setFiltersOpen(false)}
                className="flex-1 py-3 rounded-xl bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700 transition-colors"
              >
                Show {filteredProducts.length} Results
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Products;
