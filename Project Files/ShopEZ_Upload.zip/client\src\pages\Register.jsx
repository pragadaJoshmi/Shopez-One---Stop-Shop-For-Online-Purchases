import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../services/authContext';
import {
    Eye,
    EyeOff,
    Mail,
    Lock,
    User,
    AlertCircle,
    CheckCircle2,
    Zap,
    ArrowRight,
    Github,
    Chrome,
} from 'lucide-react';

/* ─── Reusable input field ─── */
const InputField = ({
    id,
    label,
    type = 'text',
    placeholder,
    value,
    onChange,
    icon: Icon,
    error,
    hint,
    rightElement,
}) => (
    <div className="flex flex-col gap-1.5">
        <label htmlFor={id} className="text-sm font-semibold text-white/80 tracking-wide">
            {label}
        </label>
        <div className="relative">
            {Icon && (
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40">
                    <Icon size={16} />
                </span>
            )}
            <input
                id={id}
                type={type}
                placeholder={placeholder}
                value={value}
                onChange={onChange}
                autoComplete="off"
                className={`w-full ${Icon ? 'pl-10' : 'pl-4'} ${rightElement ? 'pr-11' : 'pr-4'} py-3 rounded-xl bg-white/10 border text-white placeholder-white/30 text-sm outline-none transition-all duration-200 focus:bg-white/15 backdrop-blur-sm ${error
                    ? 'border-rose-400/70 focus:border-rose-400 focus:ring-2 focus:ring-rose-400/20'
                    : 'border-white/20 focus:border-violet-400/80 focus:ring-2 focus:ring-violet-400/20'
                    }`}
            />
            {rightElement && (
                <span className="absolute right-3.5 top-1/2 -translate-y-1/2">{rightElement}</span>
            )}
        </div>
        {error && (
            <p className="flex items-center gap-1.5 text-xs text-rose-300 font-medium">
                <AlertCircle size={12} />
                {error}
            </p>
        )}
        {hint && !error && (
            <p className="text-[11px] text-white/30">{hint}</p>
        )}
    </div>
);

/* ─── Password strength indicator ─── */
const getStrength = (pw) => {
    if (!pw) return 0;
    let score = 0;
    if (pw.length >= 8) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^a-zA-Z0-9]/.test(pw)) score++;
    return score;
};

const strengthLabel = ['', 'Weak', 'Fair', 'Good', 'Strong'];
const strengthColor = [
    '',
    'bg-rose-500',
    'bg-amber-400',
    'bg-yellow-400',
    'bg-emerald-400',
];

const PasswordStrength = ({ password }) => {
    const score = getStrength(password);
    if (!password) return null;
    return (
        <div className="mt-1">
            <div className="flex gap-1 mb-1">
                {[1, 2, 3, 4].map((i) => (
                    <div
                        key={i}
                        className={`flex-1 h-1 rounded-full transition-all duration-300 ${i <= score ? strengthColor[score] : 'bg-white/15'
                            }`}
                    />
                ))}
            </div>
            <p className={`text-[11px] font-semibold ${score <= 1 ? 'text-rose-400' : score === 2 ? 'text-amber-400' : score === 3 ? 'text-yellow-300' : 'text-emerald-400'}`}>
                {strengthLabel[score]} password
            </p>
        </div>
    );
};

/* ─── Social button ─── */
const SocialButton = ({ icon: Icon, label }) => (
    <button
        type="button"
        className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-white/10 border border-white/20 text-white/80 text-sm font-medium hover:bg-white/20 hover:border-white/40 active:scale-95 transition-all duration-200"
    >
        <Icon size={16} />
        {label}
    </button>
);

/* ══════════════════════════════════════
   REGISTER PAGE
══════════════════════════════════════ */
const Register = () => {
    const [form, setForm] = useState({
        fullName: '',
        email: '',
        password: '',
        confirmPassword: '',
    });
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);
    const [agreed, setAgreed] = useState(false);
    const [errors, setErrors] = useState({});
    const [authError, setAuthError] = useState('');
    const [submitted, setSubmitted] = useState(false);
    const { register } = useAuth();
    const navigate = useNavigate();

    const set = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

    const validate = () => {
        const e = {};
        if (!form.fullName.trim()) e.fullName = 'Full name is required.';
        else if (form.fullName.trim().length < 2) e.fullName = 'Name must be at least 2 characters.';

        if (!form.email.trim()) e.email = 'Email is required.';
        else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Enter a valid email address.';

        if (!form.password) e.password = 'Password is required.';
        else if (form.password.length < 8) e.password = 'Password must be at least 8 characters.';

        if (!form.confirmPassword) e.confirmPassword = 'Please confirm your password.';
        else if (form.confirmPassword !== form.password) e.confirmPassword = 'Passwords do not match.';

        if (!agreed) e.agreed = 'You must agree to the terms.';
        return e;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const errs = validate();
        setErrors(errs);
        setAuthError('');

        if (Object.keys(errs).length === 0) {
            try {
                await register(form.fullName, form.email, form.password);
                setSubmitted(true);
                setTimeout(() => navigate('/'), 2000); // Redirect to home
            } catch (err) {
                setAuthError(err?.response?.data?.message || 'Failed to register');
            }
        }
    };

    return (
        /* ── Full-screen gradient background (violet/rose tone, different from Login) ── */
        <div className="relative min-h-screen flex items-center justify-center px-4 py-12 overflow-hidden bg-gradient-to-br from-slate-900 via-violet-950 to-fuchsia-950">

            {/* Decorative blobs */}
            <div className="absolute -top-40 -right-40 w-[500px] h-[500px] bg-violet-600/25 rounded-full blur-[120px] pointer-events-none" />
            <div className="absolute -bottom-40 -left-40 w-[500px] h-[500px] bg-fuchsia-600/25 rounded-full blur-[120px] pointer-events-none" />
            <div className="absolute top-1/3 right-1/4 w-[200px] h-[200px] bg-indigo-500/10 rounded-full blur-[60px] pointer-events-none" />

            {/* ── Glassmorphism card ── */}
            <div className="relative w-full max-w-md">
                <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl shadow-2xl shadow-black/40 p-8 sm:p-10">

                    {/* Logo */}
                    <div className="flex flex-col items-center mb-7">
                        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-600 flex items-center justify-center shadow-lg shadow-violet-500/40 mb-4">
                            <Zap size={26} className="text-white" strokeWidth={2.5} />
                        </div>
                        <h1 className="text-2xl font-extrabold text-white tracking-tight">Create account</h1>
                        <p className="text-white/50 text-sm mt-1">Join thousands of ShopEZ shoppers</p>
                    </div>

                    {/* Success state */}
                    {submitted ? (
                        <div className="flex flex-col items-center gap-4 py-6">
                            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center">
                                <CheckCircle2 size={32} className="text-emerald-400" />
                            </div>
                            <p className="text-white font-semibold text-lg">Account created! 🎉</p>
                            <p className="text-white/50 text-sm text-center">
                                Welcome aboard,{' '}
                                <span className="text-violet-300 font-semibold">{form.fullName.split(' ')[0]}</span>!
                                Check your email to verify your account.
                            </p>
                            <Link
                                to="/login"
                                className="mt-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-600 text-white text-sm font-bold hover:from-violet-600 hover:to-fuchsia-700 transition-all active:scale-95"
                            >
                                Go to Login
                            </Link>
                        </div>
                    ) : (
                        <>
                            {/* Social auth */}
                            <div className="flex gap-3 mb-6">
                                <SocialButton icon={Chrome} label="Google" />
                                <SocialButton icon={Github} label="GitHub" />
                            </div>

                            {/* Divider */}
                            <div className="relative flex items-center gap-3 mb-6">
                                <div className="flex-1 h-px bg-white/15" />
                                <span className="text-white/30 text-xs font-medium">or register with email</span>
                                <div className="flex-1 h-px bg-white/15" />
                            </div>

                            {/* Global Auth Error */}
                            {authError && (
                                <div className="mb-4 p-3 bg-rose-500/20 border border-rose-500/50 rounded-xl text-rose-200 text-sm text-center">
                                    {authError}
                                </div>
                            )}

                            {/* Form */}
                            <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
                                {/* Full name */}
                                <InputField
                                    id="reg-name"
                                    label="Full name"
                                    placeholder="Joshua Smith"
                                    value={form.fullName}
                                    onChange={set('fullName')}
                                    icon={User}
                                    error={errors.fullName}
                                />

                                {/* Email */}
                                <InputField
                                    id="reg-email"
                                    label="Email address"
                                    type="email"
                                    placeholder="you@example.com"
                                    value={form.email}
                                    onChange={set('email')}
                                    icon={Mail}
                                    error={errors.email}
                                />

                                {/* Password */}
                                <div>
                                    <InputField
                                        id="reg-password"
                                        label="Password"
                                        type={showPassword ? 'text' : 'password'}
                                        placeholder="Min. 8 characters"
                                        value={form.password}
                                        onChange={set('password')}
                                        icon={Lock}
                                        error={errors.password}
                                        hint="Use 8+ chars with uppercase, numbers & symbols."
                                        rightElement={
                                            <button
                                                type="button"
                                                onClick={() => setShowPassword((v) => !v)}
                                                className="text-white/40 hover:text-white/70 transition-colors"
                                                aria-label={showPassword ? 'Hide password' : 'Show password'}
                                            >
                                                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                                            </button>
                                        }
                                    />
                                    <PasswordStrength password={form.password} />
                                </div>

                                {/* Confirm password */}
                                <InputField
                                    id="reg-confirm"
                                    label="Confirm password"
                                    type={showConfirm ? 'text' : 'password'}
                                    placeholder="Repeat your password"
                                    value={form.confirmPassword}
                                    onChange={set('confirmPassword')}
                                    icon={Lock}
                                    error={errors.confirmPassword}
                                    rightElement={
                                        <button
                                            type="button"
                                            onClick={() => setShowConfirm((v) => !v)}
                                            className="text-white/40 hover:text-white/70 transition-colors"
                                            aria-label={showConfirm ? 'Hide password' : 'Show password'}
                                        >
                                            {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
                                        </button>
                                    }
                                />

                                {/* Terms checkbox */}
                                <div>
                                    <label className="flex items-start gap-2.5 cursor-pointer group">
                                        <input
                                            type="checkbox"
                                            checked={agreed}
                                            onChange={(e) => setAgreed(e.target.checked)}
                                            className="mt-0.5 w-4 h-4 rounded accent-violet-500 cursor-pointer flex-shrink-0"
                                        />
                                        <span className="text-sm text-white/60 group-hover:text-white/80 transition-colors leading-relaxed">
                                            I agree to the{' '}
                                            <Link to="#" className="text-violet-300 hover:text-white font-semibold">
                                                Terms of Service
                                            </Link>{' '}
                                            and{' '}
                                            <Link to="#" className="text-violet-300 hover:text-white font-semibold">
                                                Privacy Policy
                                            </Link>
                                        </span>
                                    </label>
                                    {errors.agreed && (
                                        <p className="mt-1 flex items-center gap-1.5 text-xs text-rose-300 font-medium">
                                            <AlertCircle size={12} />
                                            {errors.agreed}
                                        </p>
                                    )}
                                </div>

                                {/* Submit */}
                                <button
                                    type="submit"
                                    className="mt-1 w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-600 text-white font-bold text-sm hover:from-violet-600 hover:to-fuchsia-700 active:scale-[0.98] transition-all duration-200 shadow-lg shadow-violet-500/30"
                                >
                                    Create account
                                    <ArrowRight size={16} />
                                </button>
                            </form>
                        </>
                    )}

                    {/* Footer link */}
                    <p className="mt-6 text-center text-sm text-white/40">
                        Already have an account?{' '}
                        <Link
                            to="/login"
                            className="text-violet-300 font-semibold hover:text-white transition-colors"
                        >
                            Sign in
                        </Link>
                    </p>
                </div>

                {/* Card glow */}
                <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-violet-500/10 to-fuchsia-500/5 -z-10 blur-2xl scale-105 pointer-events-none" />
            </div>
        </div>
    );
};

export default Register;
