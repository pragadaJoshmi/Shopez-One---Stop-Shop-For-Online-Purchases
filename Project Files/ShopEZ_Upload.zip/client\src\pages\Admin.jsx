import { useState, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import {
    LayoutDashboard,
    Package,
    ShoppingCart,
    Users,
    BarChart3,
    Settings,
    Bell,
    Search,
    Plus,
    TrendingUp,
    TrendingDown,
    Edit2,
    Trash2,
    Eye,
    ChevronUp,
    ChevronDown,
    X,
    Star,
    Menu,
    Zap,
    LogOut,
    Filter,
    Download,
    MoreVertical,
    CheckCircle2,
    Clock,
    XCircle,
    Truck,
} from 'lucide-react';

/* ══════════════════════════════════════════════════════════════
   DUMMY DATA
══════════════════════════════════════════════════════════════ */
const STATS = [
    {
        label: 'Total Revenue',
        value: '$48,295',
        change: '+12.5%',
        trend: 'up',
        icon: BarChart3,
        color: 'indigo',
        sub: 'vs last month',
    },
    {
        label: 'Total Orders',
        value: '1,284',
        change: '+8.2%',
        trend: 'up',
        icon: ShoppingCart,
        color: 'violet',
        sub: 'vs last month',
    },
    {
        label: 'Total Customers',
        value: '3,712',
        change: '+5.1%',
        trend: 'up',
        icon: Users,
        color: 'sky',
        sub: 'vs last month',
    },
    {
        label: 'Total Products',
        value: '16',
        change: '-2',
        trend: 'down',
        icon: Package,
        color: 'amber',
        sub: 'vs last month',
    },
];

const PRODUCTS = [
    { id: 1, name: 'Wireless Headphones Pro', category: 'Electronics', price: 129.99, stock: 45, rating: 4.5, status: 'Active', image: 'https://images.pexels.com/photos/3587478/pexels-photo-3587478.jpeg?auto=compress&cs=tinysrgb&w=100' },
    { id: 2, name: 'Minimalist Watch', category: 'Fashion', price: 89.99, stock: 30, rating: 4.7, status: 'Active', image: 'https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?auto=compress&cs=tinysrgb&w=100' },
    { id: 3, name: 'Smart Fitness Tracker', category: 'Electronics', price: 79.99, stock: 60, rating: 4.3, status: 'Active', image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=100' },
    { id: 4, name: 'Canvas Backpack', category: 'Fashion', price: 59.99, stock: 25, rating: 4.6, status: 'Active', image: 'https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg?auto=compress&cs=tinysrgb&w=100' },
    { id: 5, name: 'Portable Bluetooth Speaker', category: 'Electronics', price: 49.99, stock: 55, rating: 4.4, status: 'Active', image: 'https://images.pexels.com/photos/1279406/pexels-photo-1279406.jpeg?auto=compress&cs=tinysrgb&w=100' },
    { id: 6, name: 'Leather Bi-fold Wallet', category: 'Fashion', price: 39.99, stock: 40, rating: 4.8, status: 'Active', image: 'https://images.pexels.com/photos/5632402/pexels-photo-5632402.jpeg?auto=compress&cs=tinysrgb&w=100' },
    { id: 7, name: 'Ergonomic Wireless Mouse', category: 'Electronics', price: 29.99, stock: 3, rating: 4.2, status: 'Low Stock', image: 'https://images.pexels.com/photos/2115256/pexels-photo-2115256.jpeg?auto=compress&cs=tinysrgb&w=100' },
    { id: 8, name: 'Premium Yoga Mat', category: 'Sports', price: 34.99, stock: 0, rating: 4.6, status: 'Out of Stock', image: 'https://images.pexels.com/photos/3822668/pexels-photo-3822668.jpeg?auto=compress&cs=tinysrgb&w=100' },
];

const ORDERS = [
    { id: '#ORD-8821', customer: 'Emma Thompson', email: 'emma@mail.com', date: 'Feb 27, 2026', items: 3, total: 319.97, status: 'Delivered', avatar: 'ET' },
    { id: '#ORD-8820', customer: 'James Wilson', email: 'james@mail.com', date: 'Feb 27, 2026', items: 1, total: 129.99, status: 'Shipped', avatar: 'JW' },
    { id: '#ORD-8819', customer: 'Sophia Chen', email: 'sophia@mail.com', date: 'Feb 26, 2026', items: 2, total: 219.98, status: 'Processing', avatar: 'SC' },
    { id: '#ORD-8818', customer: 'Oliver Brown', email: 'oliver@mail.com', date: 'Feb 26, 2026', items: 4, total: 459.96, status: 'Delivered', avatar: 'OB' },
    { id: '#ORD-8817', customer: 'Ava Martinez', email: 'ava@mail.com', date: 'Feb 25, 2026', items: 1, total: 89.99, status: 'Cancelled', avatar: 'AM' },
    { id: '#ORD-8816', customer: 'Noah Davis', email: 'noah@mail.com', date: 'Feb 25, 2026', items: 2, total: 174.98, status: 'Processing', avatar: 'ND' },
    { id: '#ORD-8815', customer: 'Mia Johnson', email: 'mia@mail.com', date: 'Feb 24, 2026', items: 3, total: 284.97, status: 'Shipped', avatar: 'MJ' },
];

/* ══════════════════════════════════════════════════════════════
   UTILITY COMPONENTS
══════════════════════════════════════════════════════════════ */
const colorMap = {
    indigo: { bg: 'bg-indigo-50', icon: 'text-indigo-600', ring: 'bg-indigo-100', badge: 'bg-indigo-600' },
    violet: { bg: 'bg-violet-50', icon: 'text-violet-600', ring: 'bg-violet-100', badge: 'bg-violet-600' },
    sky: { bg: 'bg-sky-50', icon: 'text-sky-600', ring: 'bg-sky-100', badge: 'bg-sky-600' },
    amber: { bg: 'bg-amber-50', icon: 'text-amber-600', ring: 'bg-amber-100', badge: 'bg-amber-600' },
};

const statusStyles = {
    Active: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'Low Stock': 'bg-amber-50 text-amber-700 border-amber-200',
    'Out of Stock': 'bg-rose-50 text-rose-700 border-rose-200',
    Delivered: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    Shipped: 'bg-sky-50 text-sky-700 border-sky-200',
    Processing: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    Cancelled: 'bg-rose-50 text-rose-700 border-rose-200',
};

const orderStatusIcon = {
    Delivered: CheckCircle2,
    Shipped: Truck,
    Processing: Clock,
    Cancelled: XCircle,
};

/* ── Sidebar nav items ── */
const NAV_ITEMS = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'orders', label: 'Orders', icon: ShoppingCart },
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
];

/* ── Add Product Modal ── */
const CATEGORIES = ['Electronics', 'Fashion', 'Sports', 'Home'];

const AddProductModal = ({ onClose, onSave }) => {
    const [form, setForm] = useState({ name: '', category: 'Electronics', price: '', stock: '', description: '' });
    const set = (f) => (e) => setForm((p) => ({ ...p, [f]: e.target.value }));

    const inputCls = 'w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:border-transparent transition-all bg-gray-50 focus:bg-white';

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
            <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                {/* Header */}
                <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
                    <div>
                        <h2 className="font-bold text-gray-900 text-lg">Add New Product</h2>
                        <p className="text-xs text-gray-500 mt-0.5">Fill in the details below</p>
                    </div>
                    <button onClick={onClose} className="p-2 rounded-xl hover:bg-gray-100 transition-colors">
                        <X size={18} className="text-gray-500" />
                    </button>
                </div>

                {/* Body */}
                <div className="px-6 py-5 flex flex-col gap-4">
                    <div>
                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5 block">Product Name</label>
                        <input className={inputCls} placeholder="e.g. Noise-Cancelling Earbuds" value={form.name} onChange={set('name')} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5 block">Category</label>
                            <select className={inputCls} value={form.category} onChange={set('category')}>
                                {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5 block">Price ($)</label>
                            <input className={inputCls} type="number" placeholder="0.00" value={form.price} onChange={set('price')} />
                        </div>
                    </div>
                    <div>
                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5 block">Stock Quantity</label>
                        <input className={inputCls} type="number" placeholder="0" value={form.stock} onChange={set('stock')} />
                    </div>
                    <div>
                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5 block">Description</label>
                        <textarea className={`${inputCls} h-20 resize-none`} placeholder="Short product description..." value={form.description} onChange={set('description')} />
                    </div>
                </div>

                {/* Footer */}
                <div className="flex gap-3 px-6 py-4 border-t border-gray-100 bg-gray-50/50">
                    <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-100 transition-colors">
                        Cancel
                    </button>
                    <button
                        onClick={() => { onSave(form); onClose(); }}
                        className="flex-1 py-2.5 rounded-xl bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700 transition-colors shadow-md shadow-indigo-200"
                    >
                        Add Product
                    </button>
                </div>
            </div>
        </div>
    );
};

/* ══════════════════════════════════════════════════════════════
   ADMIN DASHBOARD
══════════════════════════════════════════════════════════════ */
const Admin = () => {
    const [activeNav, setActiveNav] = useState('dashboard');
    const [activeTab, setActiveTab] = useState('products'); // table tab: products | orders
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const [showAddModal, setShowAddModal] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortField, setSortField] = useState('id');
    const [sortDir, setSortDir] = useState('asc');
    const [products, setProducts] = useState(PRODUCTS);
    const [orders, setOrders] = useState([]);
    const [users, setUsers] = useState([]);
    const [notifOpen, setNotifOpen] = useState(false);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchAdminData = async () => {
            try {
                const [ordersRes, usersRes] = await Promise.all([
                    api.get('/admin/orders'),
                    api.get('/admin/users')
                ]);

                // Map API orders to matching structure for UI
                setOrders(ordersRes.data.data.map(o => ({
                    id: o._id.slice(-6).toUpperCase(), // shorten ObjectId for UI
                    customer: o.user?.name || 'Unknown',
                    email: o.user?.email || 'N/A',
                    date: new Date(o.createdAt).toLocaleDateString(),
                    items: o.items.length,
                    total: o.totalPrice,
                    status: o.isDelivered ? 'Delivered' : (o.isPaid ? 'Processing' : 'Processing'),
                    avatar: o.user?.name ? o.user.name.charAt(0).toUpperCase() : 'U'
                })));

                setUsers(usersRes.data.data);
            } catch (err) {
                console.error("Failed to fetch admin data", err);
            } finally {
                setLoading(false);
            }
        };

        fetchAdminData();
    }, []);

    /* ── Table sort ── */
    const toggleSort = (field) => {
        if (sortField === field) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
        else { setSortField(field); setSortDir('asc'); }
    };

    const SortIcon = ({ field }) => (
        <span className="ml-1 inline-flex flex-col">
            <ChevronUp size={10} className={sortField === field && sortDir === 'asc' ? 'text-indigo-600' : 'text-gray-300'} />
            <ChevronDown size={10} className={sortField === field && sortDir === 'desc' ? 'text-indigo-600' : 'text-gray-300'} />
        </span>
    );

    const filteredProducts = useMemo(() => {
        let list = products.filter(
            (p) =>
                p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                p.category.toLowerCase().includes(searchQuery.toLowerCase())
        );
        list.sort((a, b) => {
            const av = a[sortField], bv = b[sortField];
            if (typeof av === 'string') return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
            return sortDir === 'asc' ? av - bv : bv - av;
        });
        return list;
    }, [products, searchQuery, sortField, sortDir]);

    const filteredOrders = useMemo(() =>
        orders.filter((o) =>
            o.customer.toLowerCase().includes(searchQuery.toLowerCase()) ||
            o.id.toLowerCase().includes(searchQuery.toLowerCase())
        ),
        [orders, searchQuery]
    );

    const handleDeleteProduct = (id) => setProducts((p) => p.filter((pr) => pr.id !== id));
    const handleAddProduct = (form) => {
        const newP = { id: Date.now(), ...form, price: Number(form.price), stock: Number(form.stock), rating: 5.0, status: 'Active', image: 'https://images.pexels.com/photos/4386321/pexels-photo-4386321.jpeg?auto=compress&cs=tinysrgb&w=100' };
        setProducts((p) => [newP, ...p]);
    };

    /* ── Sidebar ── */
    const Sidebar = ({ mobile = false }) => (
        <aside className={`${mobile ? 'flex' : 'hidden lg:flex'} flex-col h-full w-64 bg-white border-r border-gray-100`}>
            {/* Brand */}
            <div className="px-6 py-5 border-b border-gray-100">
                <Link to="/" className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center shadow-md">
                        <Zap size={18} className="text-white" strokeWidth={2.5} />
                    </div>
                    <div>
                        <span className="font-extrabold text-gray-900 tracking-tight">Shop<span className="text-indigo-600">EZ</span></span>
                        <p className="text-[10px] text-gray-400 font-medium leading-none mt-0.5">Admin Panel</p>
                    </div>
                </Link>
            </div>

            {/* Nav */}
            <nav className="flex-1 px-3 py-4 overflow-y-auto">
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 px-3 mb-2">Main Menu</p>
                <div className="space-y-0.5">
                    {NAV_ITEMS.slice(0, 5).map(({ id, label, icon: Icon }) => (
                        <button
                            key={id}
                            onClick={() => { setActiveNav(id); setSidebarOpen(false); }}
                            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${activeNav === id
                                ? 'bg-indigo-50 text-indigo-700'
                                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                                }`}
                        >
                            <Icon size={17} className={activeNav === id ? 'text-indigo-600' : 'text-gray-400'} />
                            {label}
                            {id === 'orders' && (
                                <span className="ml-auto text-[10px] font-bold bg-indigo-600 text-white px-1.5 py-0.5 rounded-full">
                                    {orders.filter((o) => o.status === 'Processing').length}
                                </span>
                            )}
                        </button>
                    ))}
                </div>

                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 px-3 mt-5 mb-2">System</p>
                <button
                    onClick={() => { setActiveNav('settings'); setSidebarOpen(false); }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${activeNav === 'settings' ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                        }`}
                >
                    <Settings size={17} className={activeNav === 'settings' ? 'text-indigo-600' : 'text-gray-400'} />
                    Settings
                </button>
            </nav>

            {/* User footer */}
            <div className="px-3 py-4 border-t border-gray-100">
                <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-gray-50 transition-colors cursor-pointer group">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center text-white font-bold text-sm shadow-sm flex-shrink-0">A</div>
                    <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-gray-800 truncate">Admin User</p>
                        <p className="text-[11px] text-gray-400 truncate">admin@shopez.com</p>
                    </div>
                    <LogOut size={15} className="text-gray-400 group-hover:text-red-500 transition-colors flex-shrink-0" />
                </div>
            </div>
        </aside>
    );

    /* ── Stat card ── */
    const StatCard = ({ label, value, change, trend, icon: Icon, color, sub }) => {
        const c = colorMap[color];
        return (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 hover:shadow-md hover:-translate-y-0.5 transition-all duration-200">
                <div className="flex items-start justify-between mb-4">
                    <div className={`w-11 h-11 ${c.ring} rounded-xl flex items-center justify-center`}>
                        <Icon size={20} className={c.icon} />
                    </div>
                    <div className={`flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full ${trend === 'up' ? 'text-emerald-700 bg-emerald-50' : 'text-rose-600 bg-rose-50'
                        }`}>
                        {trend === 'up' ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                        {change}
                    </div>
                </div>
                <p className="text-2xl font-extrabold text-gray-900 tracking-tight">{value}</p>
                <p className="text-sm text-gray-500 mt-0.5">{label}</p>
                <p className="text-[11px] text-gray-400 mt-1">{sub}</p>
            </div>
        );
    };

    /* ── Table header cell ── */
    const Th = ({ label, field, className = '' }) => (
        <th
            onClick={() => field && toggleSort(field)}
            className={`px-4 py-3 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 ${field ? 'cursor-pointer hover:text-gray-600 select-none' : ''} ${className}`}
        >
            <span className="flex items-center">
                {label}
                {field && <SortIcon field={field} />}
            </span>
        </th>
    );

    /* ── Mini revenue chart bars (sparkline) ── */
    const Sparkline = () => {
        const bars = [40, 65, 45, 80, 55, 90, 72, 95, 60, 85, 70, 100];
        return (
            <div className="flex items-end gap-1 h-12">
                {bars.map((h, i) => (
                    <div
                        key={i}
                        className={`flex-1 rounded-sm transition-all duration-300 ${i === bars.length - 1 ? 'bg-indigo-600' : 'bg-indigo-100'}`}
                        style={{ height: `${h}%` }}
                    />
                ))}
            </div>
        );
    };

    /* ════════════════ RENDER ════════════════ */
    return (
        <div className="flex h-screen bg-slate-50 overflow-hidden">

            {/* Mobile sidebar overlay */}
            {sidebarOpen && (
                <div className="fixed inset-0 z-40 lg:hidden">
                    <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
                    <div className="absolute left-0 top-0 bottom-0 w-64 z-50 shadow-2xl">
                        <Sidebar mobile />
                    </div>
                </div>
            )}

            {/* Desktop Sidebar */}
            <Sidebar />

            {/* Add Product Modal */}
            {showAddModal && <AddProductModal onClose={() => setShowAddModal(false)} onSave={handleAddProduct} />}

            {/* ── MAIN CONTENT ── */}
            <div className="flex-1 flex flex-col min-w-0 overflow-hidden">

                {/* Topbar */}
                <header className="bg-white border-b border-gray-100 px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4 flex-shrink-0">
                    <div className="flex items-center gap-3">
                        <button
                            onClick={() => setSidebarOpen(true)}
                            className="lg:hidden p-2 rounded-xl hover:bg-gray-100 transition-colors"
                        >
                            <Menu size={20} className="text-gray-600" />
                        </button>
                        <div>
                            <h1 className="text-base font-extrabold text-gray-900 leading-none">
                                {NAV_ITEMS.find((n) => n.id === activeNav)?.label ?? 'Dashboard'}
                            </h1>
                            <p className="text-xs text-gray-400 mt-0.5">Feb 27, 2026</p>
                        </div>
                    </div>

                    <div className="flex items-center gap-2">
                        {/* Search */}
                        <div className="relative hidden sm:block">
                            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                            <input
                                type="text"
                                placeholder="Search…"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="pl-8 pr-4 py-2 text-sm rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:bg-white transition-all w-48 focus:w-64"
                            />
                        </div>

                        {/* Notification bell */}
                        <div className="relative">
                            <button
                                onClick={() => setNotifOpen((o) => !o)}
                                className="relative p-2 rounded-xl hover:bg-gray-100 transition-colors"
                            >
                                <Bell size={18} className="text-gray-600" />
                                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500" />
                            </button>
                            {notifOpen && (
                                <div className="absolute right-0 top-full mt-2 w-72 bg-white border border-gray-100 rounded-2xl shadow-xl z-30 overflow-hidden">
                                    <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
                                        <span className="text-sm font-bold text-gray-900">Notifications</span>
                                        <button onClick={() => setNotifOpen(false)}><X size={14} className="text-gray-400" /></button>
                                    </div>
                                    {[
                                        { text: 'New order #ORD-8821 received', time: '2m ago', dot: 'bg-indigo-500' },
                                        { text: 'Low stock alert: Wireless Mouse (3 left)', time: '14m ago', dot: 'bg-amber-500' },
                                        { text: 'Order #ORD-8820 shipped', time: '1h ago', dot: 'bg-emerald-500' },
                                    ].map((n, i) => (
                                        <div key={i} className="px-4 py-3 hover:bg-gray-50 flex items-start gap-3 border-b border-gray-50 last:border-0 transition-colors">
                                            <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${n.dot}`} />
                                            <div>
                                                <p className="text-xs text-gray-700 font-medium">{n.text}</p>
                                                <p className="text-[10px] text-gray-400 mt-0.5">{n.time}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>

                        {/* Add Product CTA */}
                        <button
                            onClick={() => setShowAddModal(true)}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700 active:scale-95 transition-all duration-200 shadow-md shadow-indigo-200"
                        >
                            <Plus size={15} />
                            <span className="hidden sm:inline">Add Product</span>
                        </button>
                    </div>
                </header>

                {/* Scrollable body */}
                <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-6 space-y-6">

                    {/* ── STAT CARDS ── */}
                    <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
                        {STATS.map((s) => <StatCard key={s.label} {...s} />)}
                    </div>

                    {/* ── REVENUE OVERVIEW + QUICK ORDERS ── */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

                        {/* Revenue chart card */}
                        <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                            <div className="flex items-start justify-between mb-5">
                                <div>
                                    <h2 className="font-bold text-gray-900">Revenue Overview</h2>
                                    <p className="text-xs text-gray-400 mt-0.5">Monthly performance — 2026</p>
                                </div>
                                <select className="text-xs border border-gray-200 rounded-lg px-2 py-1.5 text-gray-600 focus:outline-none focus:ring-1 focus:ring-indigo-400 bg-gray-50">
                                    <option>This year</option>
                                    <option>Last year</option>
                                </select>
                            </div>

                            {/* Bar chart */}
                            <div className="flex items-end justify-between gap-1 h-36 mb-3">
                                {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map((m, i) => {
                                    const heightPct = [52, 68, 45, 78, 62, 88, 74, 95, 63, 82, 70, 100][i];
                                    const isCur = i === 1;
                                    return (
                                        <div key={m} className="flex-1 flex flex-col items-center gap-1.5">
                                            <div
                                                className={`w-full rounded-lg transition-all duration-300 hover:opacity-80 cursor-pointer ${isCur ? 'bg-indigo-600' : 'bg-indigo-100 hover:bg-indigo-200'}`}
                                                style={{ height: `${heightPct}%` }}
                                            />
                                            <span className={`text-[9px] font-medium ${isCur ? 'text-indigo-600' : 'text-gray-400'}`}>{m}</span>
                                        </div>
                                    );
                                })}
                            </div>

                            <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                                <div className="text-center">
                                    <p className="text-xs text-gray-400">Feb Revenue</p>
                                    <p className="text-sm font-bold text-gray-900">$12,480</p>
                                </div>
                                <div className="text-center">
                                    <p className="text-xs text-gray-400">Avg Order</p>
                                    <p className="text-sm font-bold text-gray-900">$97.20</p>
                                </div>
                                <div className="text-center">
                                    <p className="text-xs text-gray-400">Orders</p>
                                    <p className="text-sm font-bold text-gray-900">128</p>
                                </div>
                                <div className="text-center">
                                    <p className="text-xs text-gray-400">Growth</p>
                                    <p className="text-sm font-bold text-emerald-600">+12.5%</p>
                                </div>
                            </div>
                        </div>

                        {/* Recent activity */}
                        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="font-bold text-gray-900">Recent Activity</h2>
                                <button className="text-xs text-indigo-600 font-semibold hover:underline">View all</button>
                            </div>
                            <div className="space-y-3">
                                {orders.slice(0, 5).map((o) => {
                                    const StatusIcon = orderStatusIcon[o.status] ?? CheckCircle2;
                                    return (
                                        <div key={o.id} className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-white text-[11px] font-bold flex-shrink-0">
                                                {o.avatar}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <p className="text-xs font-semibold text-gray-800 truncate">{o.customer}</p>
                                                <p className="text-[10px] text-gray-400">{o.id} · ${o.total}</p>
                                            </div>
                                            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${statusStyles[o.status]}`}>
                                                {o.status}
                                            </span>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>

                    {/* ── TABLES ── */}
                    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                        {/* Table header */}
                        <div className="px-5 py-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center gap-3">
                            {/* Tabs */}
                            <div className="flex bg-gray-100 rounded-xl p-1 gap-1">
                                {['products', 'orders'].map((tab) => (
                                    <button
                                        key={tab}
                                        onClick={() => setActiveTab(tab)}
                                        className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all duration-150 capitalize ${activeTab === tab
                                            ? 'bg-white text-indigo-700 shadow-sm'
                                            : 'text-gray-500 hover:text-gray-700'
                                            }`}
                                    >
                                        {tab}
                                        <span className="ml-1.5 text-[10px] opacity-70">
                                            ({tab === 'products' ? filteredProducts.length : filteredOrders.length})
                                        </span>
                                    </button>
                                ))}
                            </div>

                            <div className="flex items-center gap-2 sm:ml-auto">
                                <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-gray-200 text-xs text-gray-600 font-medium hover:bg-gray-50 transition-colors">
                                    <Filter size={12} />
                                    Filter
                                </button>
                                <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-gray-200 text-xs text-gray-600 font-medium hover:bg-gray-50 transition-colors">
                                    <Download size={12} />
                                    Export
                                </button>
                            </div>
                        </div>

                        {/* ── PRODUCTS TABLE ── */}
                        {activeTab === 'products' && (
                            <div className="overflow-x-auto">
                                <table className="w-full">
                                    <thead className="bg-gray-50/60">
                                        <tr>
                                            <Th label="Product" field="name" />
                                            <Th label="Category" field="category" />
                                            <Th label="Price" field="price" />
                                            <Th label="Stock" field="stock" />
                                            <Th label="Rating" field="rating" />
                                            <Th label="Status" />
                                            <Th label="Actions" className="text-right" />
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-50">
                                        {filteredProducts.map((p) => (
                                            <tr key={p.id} className="hover:bg-indigo-50/30 transition-colors group">
                                                <td className="px-4 py-3">
                                                    <div className="flex items-center gap-3">
                                                        <img src={p.image} alt={p.name} className="w-9 h-9 rounded-xl object-cover flex-shrink-0 border border-gray-100 group-hover:scale-105 transition-transform duration-200" />
                                                        <span className="text-sm font-semibold text-gray-800 line-clamp-1">{p.name}</span>
                                                    </div>
                                                </td>
                                                <td className="px-4 py-3">
                                                    <span className="text-xs bg-gray-100 text-gray-600 px-2.5 py-1 rounded-lg font-medium">{p.category}</span>
                                                </td>
                                                <td className="px-4 py-3 text-sm font-bold text-gray-900">${p.price.toFixed(2)}</td>
                                                <td className="px-4 py-3">
                                                    <span className={`text-sm font-semibold ${p.stock === 0 ? 'text-rose-600' : p.stock < 10 ? 'text-amber-600' : 'text-gray-800'}`}>
                                                        {p.stock}
                                                    </span>
                                                </td>
                                                <td className="px-4 py-3">
                                                    <div className="flex items-center gap-1">
                                                        <Star size={12} className="text-amber-400 fill-amber-400" />
                                                        <span className="text-xs font-semibold text-gray-700">{p.rating}</span>
                                                    </div>
                                                </td>
                                                <td className="px-4 py-3">
                                                    <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full border ${statusStyles[p.status]}`}>
                                                        {p.status}
                                                    </span>
                                                </td>
                                                <td className="px-4 py-3">
                                                    <div className="flex items-center justify-end gap-1">
                                                        <button className="p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors" title="View">
                                                            <Eye size={14} />
                                                        </button>
                                                        <button className="p-1.5 text-gray-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors" title="Edit">
                                                            <Edit2 size={14} />
                                                        </button>
                                                        <button
                                                            onClick={() => handleDeleteProduct(p.id)}
                                                            className="p-1.5 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                                                            title="Delete"
                                                        >
                                                            <Trash2 size={14} />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                                {filteredProducts.length === 0 && (
                                    <div className="flex flex-col items-center py-16 text-center">
                                        <Package size={36} className="text-gray-300 mb-3" />
                                        <p className="text-sm font-semibold text-gray-500">No products found</p>
                                        <p className="text-xs text-gray-400 mt-1">Try adjusting your search</p>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* ── ORDERS TABLE ── */}
                        {activeTab === 'orders' && (
                            <div className="overflow-x-auto">
                                <table className="w-full">
                                    <thead className="bg-gray-50/60">
                                        <tr>
                                            <Th label="Order ID" />
                                            <Th label="Customer" />
                                            <Th label="Date" />
                                            <Th label="Items" />
                                            <Th label="Total" />
                                            <Th label="Status" />
                                            <Th label="" />
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-50">
                                        {filteredOrders.map((o) => {
                                            const StatusIcon = orderStatusIcon[o.status] ?? CheckCircle2;
                                            return (
                                                <tr key={o.id} className="hover:bg-indigo-50/30 transition-colors group">
                                                    <td className="px-4 py-3">
                                                        <span className="text-sm font-mono font-bold text-indigo-700">{o.id}</span>
                                                    </td>
                                                    <td className="px-4 py-3">
                                                        <div className="flex items-center gap-2.5">
                                                            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0">
                                                                {o.avatar}
                                                            </div>
                                                            <div>
                                                                <p className="text-sm font-semibold text-gray-800 leading-none">{o.customer}</p>
                                                                <p className="text-[10px] text-gray-400 mt-0.5">{o.email}</p>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td className="px-4 py-3 text-xs text-gray-500">{o.date}</td>
                                                    <td className="px-4 py-3 text-sm font-semibold text-gray-700">{o.items}</td>
                                                    <td className="px-4 py-3 text-sm font-bold text-gray-900">${o.total.toFixed(2)}</td>
                                                    <td className="px-4 py-3">
                                                        <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full border ${statusStyles[o.status]}`}>
                                                            <StatusIcon size={10} />
                                                            {o.status}
                                                        </span>
                                                    </td>
                                                    <td className="px-4 py-3">
                                                        <button className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                                                            <MoreVertical size={14} />
                                                        </button>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                                {filteredOrders.length === 0 && (
                                    <div className="flex flex-col items-center py-16">
                                        <ShoppingCart size={36} className="text-gray-300 mb-3" />
                                        <p className="text-sm font-semibold text-gray-500">No orders found</p>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Table footer */}
                        <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
                            <p className="text-xs text-gray-400">
                                Showing {activeTab === 'products' ? filteredProducts.length : filteredOrders.length}{' '}
                                {activeTab === 'products' ? 'products' : 'orders'}
                            </p>
                            <div className="flex items-center gap-1">
                                {[1, 2, 3].map((pg) => (
                                    <button
                                        key={pg}
                                        className={`w-7 h-7 rounded-lg text-xs font-semibold transition-colors ${pg === 1 ? 'bg-indigo-600 text-white' : 'text-gray-500 hover:bg-gray-100'
                                            }`}
                                    >
                                        {pg}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Admin;
