import { useState, useEffect, useRef } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import {
    ShoppingCart,
    Menu,
    X,
    ChevronDown,
    User,
    LogOut,
    Settings,
    ShieldCheck,
    Zap,
} from 'lucide-react';
import { useCart } from '../services/cartContext';
import { useAuth } from '../services/authContext';

/* ─── Active link helper ─── */
const navLinkClass = ({ isActive }) =>
    `relative text-sm font-medium transition-colors duration-200 group ${isActive ? 'text-indigo-600' : 'text-gray-600 hover:text-indigo-600'
    }`;

/* ─── Underline decoration ─── */
const NavUnderline = ({ isActive }) => (
    <span
        className={`absolute -bottom-1 left-0 h-0.5 rounded-full bg-indigo-600 transition-all duration-300 ${isActive ? 'w-full' : 'w-0 group-hover:w-full'
            }`}
    />
);

const Navbar = () => {
    const { getCartCount } = useCart();
    const { user, isAdmin, logout, loginAsUser, loginAsAdmin } = useAuth();
    const navigate = useNavigate();

    const [mobileOpen, setMobileOpen] = useState(false);
    const [profileOpen, setProfileOpen] = useState(false);
    const [scrolled, setScrolled] = useState(false);

    const profileRef = useRef(null);
    const cartCount = getCartCount();

    /* ── Shadow on scroll ── */
    useEffect(() => {
        const handleScroll = () => setScrolled(window.scrollY > 8);
        window.addEventListener('scroll', handleScroll, { passive: true });
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    /* ── Close profile dropdown on outside click ── */
    useEffect(() => {
        const onOutside = (e) => {
            if (profileRef.current && !profileRef.current.contains(e.target)) {
                setProfileOpen(false);
            }
        };
        document.addEventListener('mousedown', onOutside);
        return () => document.removeEventListener('mousedown', onOutside);
    }, []);

    /* ── Close mobile menu on route change ── */
    const closeMobile = () => setMobileOpen(false);

    const handleLogout = () => {
        logout();
        setProfileOpen(false);
        setMobileOpen(false);
        navigate('/');
    };

    const navLinks = [
        { to: '/', label: 'Home', end: true },
        { to: '/products', label: 'Products' },
    ];

    return (
        <>
            <header
                className={`sticky top-0 z-50 bg-white transition-shadow duration-300 ${scrolled ? 'shadow-md' : 'shadow-sm'
                    }`}
            >
                {/* ── Top announcement bar ── */}
                <div className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white text-center text-xs py-1.5 font-medium tracking-wide">
                    🎉 Free shipping on orders over $50 · Use code&nbsp;
                    <span className="font-bold underline underline-offset-2">SHOPEZ10</span>
                </div>

                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-16">

                        {/* ── LOGO ── */}
                        <Link
                            to="/"
                            className="flex items-center gap-2 group flex-shrink-0"
                            aria-label="ShopEZ home"
                        >
                            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center shadow-md group-hover:shadow-indigo-300 transition-shadow duration-300">
                                <Zap size={18} className="text-white" strokeWidth={2.5} />
                            </div>
                            <span className="text-xl font-extrabold tracking-tight text-gray-900 group-hover:text-indigo-700 transition-colors duration-200">
                                Shop<span className="text-indigo-600">EZ</span>
                            </span>
                        </Link>

                        {/* ── DESKTOP NAV ── */}
                        <nav className="hidden md:flex items-center gap-8" aria-label="Main navigation">
                            {navLinks.map(({ to, label, end }) => (
                                <NavLink key={to} to={to} end={end} className={navLinkClass}>
                                    {({ isActive }) => (
                                        <>
                                            {label}
                                            <NavUnderline isActive={isActive} />
                                        </>
                                    )}
                                </NavLink>
                            ))}

                            {/* Admin link — conditional */}
                            {isAdmin && (
                                <NavLink to="/admin" className={navLinkClass}>
                                    {({ isActive }) => (
                                        <>
                                            <span className="flex items-center gap-1">
                                                <ShieldCheck size={15} className="text-amber-500" />
                                                Admin
                                            </span>
                                            <NavUnderline isActive={isActive} />
                                        </>
                                    )}
                                </NavLink>
                            )}
                        </nav>

                        {/* ── DESKTOP RIGHT ACTIONS ── */}
                        <div className="hidden md:flex items-center gap-3">

                            {/* Cart */}
                            <Link
                                to="/cart"
                                className="relative p-2 rounded-xl text-gray-600 hover:text-indigo-600 hover:bg-indigo-50 transition-all duration-200"
                                aria-label={`Cart, ${cartCount} items`}
                            >
                                <ShoppingCart size={22} />
                                {cartCount > 0 && (
                                    <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1 bg-indigo-600 text-white text-[11px] font-bold rounded-full flex items-center justify-center leading-none animate-pulse">
                                        {cartCount > 99 ? '99+' : cartCount}
                                    </span>
                                )}
                            </Link>

                            {/* Profile / Login dropdown */}
                            {user ? (
                                <div className="relative" ref={profileRef}>
                                    <button
                                        onClick={() => setProfileOpen((o) => !o)}
                                        className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-xl text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 transition-all duration-200 border border-transparent hover:border-indigo-100"
                                        aria-haspopup="true"
                                        aria-expanded={profileOpen}
                                    >
                                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center text-white font-bold text-sm shadow">
                                            {user.name?.charAt(0).toUpperCase()}
                                        </div>
                                        <span className="text-sm font-medium max-w-[80px] truncate">{user.name}</span>
                                        <ChevronDown
                                            size={14}
                                            className={`transition-transform duration-200 ${profileOpen ? 'rotate-180' : ''}`}
                                        />
                                    </button>

                                    {/* Dropdown */}
                                    {profileOpen && (
                                        <div className="absolute right-0 top-full mt-2 w-52 bg-white border border-gray-100 rounded-2xl shadow-xl shadow-gray-200/60 overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                                            <div className="px-4 py-3 border-b border-gray-100">
                                                <p className="text-xs text-gray-400 font-medium">Signed in as</p>
                                                <p className="text-sm font-semibold text-gray-800 truncate">{user.email}</p>
                                            </div>
                                            <div className="py-1">
                                                <Link
                                                    to="/profile"
                                                    onClick={() => setProfileOpen(false)}
                                                    className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 transition-colors"
                                                >
                                                    <User size={15} /> My Profile
                                                </Link>
                                                <Link
                                                    to="/orders"
                                                    onClick={() => setProfileOpen(false)}
                                                    className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 transition-colors"
                                                >
                                                    <Settings size={15} /> Orders & Settings
                                                </Link>
                                                {isAdmin && (
                                                    <Link
                                                        to="/admin"
                                                        onClick={() => setProfileOpen(false)}
                                                        className="flex items-center gap-3 px-4 py-2.5 text-sm text-amber-600 hover:bg-amber-50 transition-colors"
                                                    >
                                                        <ShieldCheck size={15} /> Admin Panel
                                                    </Link>
                                                )}
                                            </div>
                                            <div className="border-t border-gray-100 py-1">
                                                <button
                                                    onClick={handleLogout}
                                                    className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 transition-colors"
                                                >
                                                    <LogOut size={15} /> Sign out
                                                </button>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            ) : (
                                <Link
                                    to="/login"
                                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700 active:scale-95 transition-all duration-200 shadow-md shadow-indigo-200"
                                >
                                    <User size={15} />
                                    Login
                                </Link>
                            )}
                        </div>

                        {/* ── MOBILE: Cart + Hamburger ── */}
                        <div className="flex md:hidden items-center gap-2">
                            <Link
                                to="/cart"
                                className="relative p-2 rounded-xl text-gray-600 hover:text-indigo-600 hover:bg-indigo-50 transition-all duration-200"
                                aria-label={`Cart, ${cartCount} items`}
                            >
                                <ShoppingCart size={22} />
                                {cartCount > 0 && (
                                    <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1 bg-indigo-600 text-white text-[11px] font-bold rounded-full flex items-center justify-center leading-none">
                                        {cartCount > 99 ? '99+' : cartCount}
                                    </span>
                                )}
                            </Link>
                            <button
                                onClick={() => setMobileOpen((o) => !o)}
                                className="p-2 rounded-xl text-gray-600 hover:text-indigo-600 hover:bg-indigo-50 transition-all duration-200"
                                aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
                                aria-expanded={mobileOpen}
                            >
                                {mobileOpen ? <X size={22} /> : <Menu size={22} />}
                            </button>
                        </div>
                    </div>
                </div>

                {/* ── MOBILE MENU ── */}
                <div
                    className={`md:hidden overflow-hidden transition-all duration-300 ease-in-out ${mobileOpen ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0'
                        }`}
                >
                    <nav className="bg-white border-t border-gray-100 px-4 py-4 flex flex-col gap-1" aria-label="Mobile navigation">
                        {navLinks.map(({ to, label, end }) => (
                            <NavLink
                                key={to}
                                to={to}
                                end={end}
                                onClick={closeMobile}
                                className={({ isActive }) =>
                                    `flex items-center px-3 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${isActive
                                        ? 'bg-indigo-50 text-indigo-700'
                                        : 'text-gray-700 hover:bg-gray-50 hover:text-indigo-600'
                                    }`
                                }
                            >
                                {label}
                            </NavLink>
                        ))}

                        {isAdmin && (
                            <NavLink
                                to="/admin"
                                onClick={closeMobile}
                                className={({ isActive }) =>
                                    `flex items-center gap-2 px-3 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${isActive
                                        ? 'bg-amber-50 text-amber-700'
                                        : 'text-gray-700 hover:bg-amber-50 hover:text-amber-600'
                                    }`
                                }
                            >
                                <ShieldCheck size={15} className="text-amber-500" />
                                Admin
                            </NavLink>
                        )}

                        <div className="mt-2 pt-3 border-t border-gray-100">
                            {user ? (
                                <>
                                    <div className="flex items-center gap-3 px-3 py-2 mb-1">
                                        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center text-white font-bold shadow">
                                            {user.name?.charAt(0).toUpperCase()}
                                        </div>
                                        <div>
                                            <p className="text-sm font-semibold text-gray-800">{user.name}</p>
                                            <p className="text-xs text-gray-400 truncate">{user.email}</p>
                                        </div>
                                    </div>
                                    <Link
                                        to="/profile"
                                        onClick={closeMobile}
                                        className="flex items-center gap-2 px-3 py-3 rounded-xl text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                                    >
                                        <User size={15} /> My Profile
                                    </Link>
                                    <button
                                        onClick={handleLogout}
                                        className="w-full flex items-center gap-2 px-3 py-3 rounded-xl text-sm text-red-500 hover:bg-red-50 transition-colors"
                                    >
                                        <LogOut size={15} /> Sign out
                                    </button>
                                </>
                            ) : (
                                <Link
                                    to="/login"
                                    onClick={closeMobile}
                                    className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700 transition-all duration-200 shadow-md shadow-indigo-200"
                                >
                                    <User size={15} />
                                    Login / Sign Up
                                </Link>
                            )}
                        </div>

                        {/* Demo toolbar — remove in production */}
                        <div className="mt-3 p-3 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                            <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">
                                Demo controls
                            </p>
                            <div className="flex gap-2">
                                <button
                                    onClick={() => { loginAsUser(); closeMobile(); }}
                                    className="flex-1 text-xs py-1.5 rounded-lg bg-indigo-100 text-indigo-700 font-medium hover:bg-indigo-200 transition-colors"
                                >
                                    User
                                </button>
                                <button
                                    onClick={() => { loginAsAdmin(); closeMobile(); }}
                                    className="flex-1 text-xs py-1.5 rounded-lg bg-amber-100 text-amber-700 font-medium hover:bg-amber-200 transition-colors"
                                >
                                    Admin
                                </button>
                                <button
                                    onClick={() => { logout(); closeMobile(); }}
                                    className="flex-1 text-xs py-1.5 rounded-lg bg-gray-200 text-gray-600 font-medium hover:bg-gray-300 transition-colors"
                                >
                                    Logout
                                </button>
                            </div>
                        </div>
                    </nav>
                </div>
            </header>
        </>
    );
};

export default Navbar;
