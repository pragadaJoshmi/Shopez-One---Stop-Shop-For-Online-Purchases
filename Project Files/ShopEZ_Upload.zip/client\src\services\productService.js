import api from './api';

export const productService = {
  /* GET /api/products  — optionally filter by category */
  getAllProducts: async (params = {}) => {
    try {
      const response = await api.get('/products', { params });
      return response.data.data; // unwrap { success, count, data }
    } catch (error) {
      console.error('Error fetching products:', error.message);
      throw error;
    }
  },

  /* GET /api/products/:id */
  getProductById: async (id) => {
    try {
      const response = await api.get(`/products/${id}`);
      return response.data.data;
    } catch (error) {
      console.error('Error fetching product:', error.message);
      throw error;
    }
  },

  /* GET /api/products?category=X */
  getProductsByCategory: async (category) => {
    try {
      const response = await api.get('/products', { params: { category } });
      return response.data.data;
    } catch (error) {
      console.error('Error fetching products by category:', error.message);
      throw error;
    }
  },

  /* GET /api/products?sort=-rating (assumed featured = highest rated) */
  getFeaturedProducts: async () => {
    try {
      const response = await api.get('/products', { params: { sort: 'rating' } });
      return response.data.data;
    } catch (error) {
      console.error('Error fetching featured products:', error.message);
      throw error;
    }
  },

  /* POST /api/products */
  createProduct: async (productData) => {
    try {
      const response = await api.post('/products', productData);
      return response.data.data;
    } catch (error) {
      console.error('Error creating product:', error.message);
      throw error;
    }
  },
};

