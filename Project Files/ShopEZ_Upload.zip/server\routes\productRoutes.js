import express from 'express';
import Product from '../models/Product.js';

const router = express.Router();

/* ──────────────────────────────────────
   GET /api/products
   Fetch all products
   Query params: ?category=Electronics&sort=price
────────────────────────────────────── */
router.get('/', async (req, res) => {
    try {
        const { category, sort } = req.query;

        // Build filter
        const filter = {};
        if (category) filter.category = category;

        // Build sort option
        const sortOption = {};
        if (sort === 'price') sortOption.price = 1;
        else if (sort === '-price') sortOption.price = -1;
        else if (sort === 'rating') sortOption.rating = -1;
        else sortOption.createdAt = -1; // Default: newest first

        const products = await Product.find(filter).sort(sortOption);

        res.status(200).json({
            success: true,
            count: products.length,
            data: products,
        });
    } catch (err) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch products',
            error: err.message,
        });
    }
});

/* ──────────────────────────────────────
   GET /api/products/:id
   Fetch a single product by ID
────────────────────────────────────── */
router.get('/:id', async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);

        if (!product) {
            return res.status(404).json({
                success: false,
                message: `Product with id "${req.params.id}" not found`,
            });
        }

        res.status(200).json({
            success: true,
            data: product,
        });
    } catch (err) {
        // Invalid ObjectId format
        if (err.name === 'CastError') {
            return res.status(400).json({
                success: false,
                message: 'Invalid product ID format',
            });
        }
        res.status(500).json({
            success: false,
            message: 'Failed to fetch product',
            error: err.message,
        });
    }
});

/* ──────────────────────────────────────
   POST /api/products
   Add a new product
────────────────────────────────────── */
router.post('/', async (req, res) => {
    try {
        const { name, description, price, category, image, rating } = req.body;

        // Basic validation
        if (!name || price === undefined) {
            return res.status(400).json({
                success: false,
                message: 'Name and price are required fields',
            });
        }

        const product = await Product.create({
            name,
            description,
            price,
            category,
            image,
            rating,
        });

        res.status(201).json({
            success: true,
            message: 'Product created successfully',
            data: product,
        });
    } catch (err) {
        // Mongoose validation error
        if (err.name === 'ValidationError') {
            const messages = Object.values(err.errors).map((e) => e.message);
            return res.status(400).json({
                success: false,
                message: messages.join(', '),
            });
        }

        res.status(500).json({
            success: false,
            message: 'Failed to create product',
            error: err.message,
        });
    }
});

export default router;
