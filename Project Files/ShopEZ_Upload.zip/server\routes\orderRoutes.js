import express from 'express';
import Order from '../models/Order.js';
import { protect, admin } from '../middleware/authMiddleware.js';

const router = express.Router();

/* ──────────────────────────────────────
   POST /api/orders
   Create a new order from cart
────────────────────────────────────── */
router.post('/', protect, async (req, res) => {
    try {
        const {
            orderItems,
            shippingAddress,
            paymentMethod,
            totalPrice,
        } = req.body;

        if (orderItems && orderItems.length === 0) {
            return res.status(400).json({ success: false, message: 'No order items' });
        } else {
            const order = new Order({
                user: req.user._id,
                items: orderItems.map(item => ({
                    product: item.id || item._id,
                    name: item.name,
                    quantity: item.quantity,
                    price: item.price,
                    image: item.image,
                })),
                shippingAddress,
                paymentMethod,
                totalPrice,
                isPaid: true, // For demo purposes, marking as paid
                paidAt: Date.now(),
            });

            const createdOrder = await order.save();

            res.status(201).json({ success: true, data: createdOrder });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server Error', error: error.message });
    }
});

/* ──────────────────────────────────────
   GET /api/orders/myorders
   Get logged in user orders
────────────────────────────────────── */
router.get('/myorders', protect, async (req, res) => {
    try {
        const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
        res.json({ success: true, count: orders.length, data: orders });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server Error', error: error.message });
    }
});

/* ──────────────────────────────────────
   GET /api/orders/:id
   Get order by ID
────────────────────────────────────── */
router.get('/:id', protect, async (req, res) => {
    try {
        const order = await Order.findById(req.params.id).populate('user', 'name email');

        if (order) {
            // Check if user is admin or the order belongs to the user
            if (order.user._id.toString() === req.user._id.toString() || req.user.isAdmin) {
                return res.json({ success: true, data: order });
            } else {
                return res.status(403).json({ success: false, message: 'Not authorized to view this order' });
            }
        } else {
            res.status(404).json({ success: false, message: 'Order not found' });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server Error', error: error.message });
    }
});

/* ──────────────────────────────────────
   GET /api/orders
   Get all orders (Admin only)
────────────────────────────────────── */
router.get('/', protect, admin, async (req, res) => {
    try {
        const orders = await Order.find({}).populate('user', 'id name email').sort({ createdAt: -1 });
        res.json({ success: true, count: orders.length, data: orders });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server Error', error: error.message });
    }
});

export default router;
