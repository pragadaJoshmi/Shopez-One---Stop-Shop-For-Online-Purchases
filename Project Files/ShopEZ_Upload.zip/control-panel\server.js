/**
 * ShopEZ System Control Panel
 * ----------------------------
 * 
 * IMPORTANT: You do NOT need to run this server.js file to use the Control Panel!
 * This was kept here just to maintain your folder structure cleanly.
 * 
 * To use the Visual Verification Dashboard:
 * 1. Open your File Explorer.
 * 2. Go into the "public" folder inside "control-panel".
 * 3. DOUBLE-CLICK on "index.html" to open it in any browser (Chrome/Edge/Safari).
 * 
 * That's it! NO npm, NO build, NO terminal commands required for the dashboard.
 */

console.log("\n=========================================================");
console.log("              ShopEZ SYSTEM CONTROL PANEL                ");
console.log("=========================================================");
console.log("\n  🛑 STOP: You don't need to run this Node file.");
console.log("  🟢 GO:   Simply open your folder in Windows, and ");
console.log("           DOUBLE-CLICK `public/index.html` to open it.");
console.log("\n=========================================================\n");
