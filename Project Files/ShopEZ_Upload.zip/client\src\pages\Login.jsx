import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../services/authContext';
import {
    Eye,
    EyeOff,
    Mail,
    Lock,
    AlertCircle,
    Zap,
    ArrowRight,
    Github,
    Chrome,
} from 'lucide-react';

/* ─── Reusable input field ─── */
const InputField = ({
    id,
    label,
    type = 'text',
    placeholder,
    value,
    onChange,
    icon: Icon,
    error,
    rightElement,
}) => (
    <div className="flex flex-col gap-1.5">
        <label htmlFor={id} className="text-sm font-semibold text-white/80 tracking-wide">
            {label}
        </label>
        <div className="relative">
            {Icon && (
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40">
                    <Icon size={16} />
                </span>
            )}
            <input
                id={id}
                type={type}
                placeholder={placeholder}
                value={value}
                onChange={onChange}
                autoComplete="off"
                className={`w-full ${Icon ? 'pl-10' : 'pl-4'} ${rightElement ? 'pr-11' : 'pr-4'
                    } py-3 rounded-xl bg-white/10 border text-white placeholder-white/30 text-sm outline-none transition-all duration-200 focus:bg-white/15 backdrop-blur-sm ${error
                        ? 'border-rose-400/70 focus:border-rose-400 focus:ring-2 focus:ring-rose-400/20'
                        : 'border-white/20 focus:border-indigo-400/80 focus:ring-2 focus:ring-indigo-400/20'
                    }`}
            />
            {rightElement && (
                <span className="absolute right-3.5 top-1/2 -translate-y-1/2">{rightElement}</span>
            )}
        </div>
        {error && (
            <p className="flex items-center gap-1.5 text-xs text-rose-300 font-medium">
                <AlertCircle size={12} />
                {error}
            </p>
        )}
    </div>
);

/* ─── Social auth button ─── */
const SocialButton = ({ icon: Icon, label, onClick }) => (
    <button
        type="button"
        onClick={onClick}
        className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-white/10 border border-white/20 text-white/80 text-sm font-medium hover:bg-white/20 hover:border-white/40 active:scale-95 transition-all duration-200"
    >
        <Icon size={16} />
        {label}
    </button>
);

/* ══════════════════════════════════════
   LOGIN PAGE
══════════════════════════════════════ */
const Login = () => {
    /* Form state */
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);

    /* Error state */
    const [authError, setAuthError] = useState('');
    const [errors, setErrors] = useState({});
    const [submitted, setSubmitted] = useState(false);
    const { login } = useAuth();
    const navigate = useNavigate();

    const validate = () => {
        const e = {};
        if (!email.trim()) e.email = 'Email is required.';
        else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) e.email = 'Enter a valid email address.';
        if (!password) e.password = 'Password is required.';
        else if (password.length < 6) e.password = 'Password must be at least 6 characters.';
        return e;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const errs = validate();
        setErrors(errs);
        setAuthError('');

        if (Object.keys(errs).length === 0) {
            try {
                await login(email, password);
                setSubmitted(true);
                setTimeout(() => navigate('/'), 1500); // Redirect to home
            } catch (err) {
                setAuthError(err?.response?.data?.message || 'Failed to login');
            }
        }
    };

    return (
        /* ── Full-screen gradient background ── */
        <div className="relative min-h-screen flex items-center justify-center px-4 py-12 overflow-hidden bg-gradient-to-br from-slate-900 via-indigo-950 to-violet-950">

            {/* Decorative blobs */}
            <div className="absolute -top-40 -left-40 w-[500px] h-[500px] bg-indigo-600/30 rounded-full blur-[120px] pointer-events-none" />
            <div className="absolute -bottom-40 -right-40 w-[500px] h-[500px] bg-violet-600/30 rounded-full blur-[120px] pointer-events-none" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-indigo-500/10 rounded-full blur-[80px] pointer-events-none" />

            {/* ── Glassmorphism card ── */}
            <div className="relative w-full max-w-md">
                <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl shadow-2xl shadow-black/40 p-8 sm:p-10">

                    {/* Logo */}
                    <div className="flex flex-col items-center mb-8">
                        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/40 mb-4">
                            <Zap size={26} className="text-white" strokeWidth={2.5} />
                        </div>
                        <h1 className="text-2xl font-extrabold text-white tracking-tight">
                            Welcome back
                        </h1>
                        <p className="text-white/50 text-sm mt-1">Sign in to your ShopEZ account</p>
                    </div>

                    {/* Success state */}
                    {submitted ? (
                        <div className="flex flex-col items-center gap-3 py-6">
                            <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center">
                                <span className="text-2xl">✓</span>
                            </div>
                            <p className="text-white font-semibold">Signed in successfully!</p>
                            <p className="text-white/50 text-xs">Redirecting you now…</p>
                        </div>
                    ) : (
                        <>
                            {/* Social auth */}
                            <div className="flex gap-3 mb-6">
                                <SocialButton icon={Chrome} label="Google" onClick={() => { }} />
                                <SocialButton icon={Github} label="GitHub" onClick={() => { }} />
                            </div>

                            {/* Divider */}
                            <div className="relative flex items-center gap-3 mb-6">
                                <div className="flex-1 h-px bg-white/15" />
                                <span className="text-white/30 text-xs font-medium">or continue with email</span>
                                <div className="flex-1 h-px bg-white/15" />
                            </div>

                            {/* Global Auth Error */}
                            {authError && (
                                <div className="mb-4 p-3 bg-rose-500/20 border border-rose-500/50 rounded-xl text-rose-200 text-sm text-center">
                                    {authError}
                                </div>
                            )}

                            {/* Form */}
                            <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-5">
                                <InputField
                                    id="login-email"
                                    label="Email address"
                                    type="email"
                                    placeholder="you@example.com"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    icon={Mail}
                                    error={errors.email}
                                />

                                <InputField
                                    id="login-password"
                                    label="Password"
                                    type={showPassword ? 'text' : 'password'}
                                    placeholder="••••••••"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    icon={Lock}
                                    error={errors.password}
                                    rightElement={
                                        <button
                                            type="button"
                                            onClick={() => setShowPassword((v) => !v)}
                                            className="text-white/40 hover:text-white/70 transition-colors"
                                            aria-label={showPassword ? 'Hide password' : 'Show password'}
                                        >
                                            {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                                        </button>
                                    }
                                />

                                {/* Forgot password */}
                                <div className="flex justify-end -mt-2">
                                    <Link
                                        to="#"
                                        className="text-xs text-indigo-300 hover:text-white font-medium transition-colors"
                                    >
                                        Forgot password?
                                    </Link>
                                </div>

                                {/* Remember me */}
                                <label className="flex items-center gap-2.5 cursor-pointer group">
                                    <input
                                        type="checkbox"
                                        className="w-4 h-4 rounded accent-indigo-500 cursor-pointer"
                                    />
                                    <span className="text-sm text-white/60 group-hover:text-white/80 transition-colors">
                                        Keep me signed in
                                    </span>
                                </label>

                                {/* Submit */}
                                <button
                                    type="submit"
                                    className="mt-1 w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-600 text-white font-bold text-sm hover:from-indigo-600 hover:to-violet-700 active:scale-[0.98] transition-all duration-200 shadow-lg shadow-indigo-500/30"
                                >
                                    Sign in
                                    <ArrowRight size={16} />
                                </button>
                            </form>
                        </>
                    )}

                    {/* Footer link */}
                    <p className="mt-7 text-center text-sm text-white/40">
                        Don't have an account?{' '}
                        <Link
                            to="/register"
                            className="text-indigo-300 font-semibold hover:text-white transition-colors"
                        >
                            Create one
                        </Link>
                    </p>
                </div>

                {/* Subtle card glow */}
                <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-indigo-500/10 to-violet-500/5 -z-10 blur-2xl scale-105 pointer-events-none" />
            </div>
        </div>
    );
};

export default Login;
