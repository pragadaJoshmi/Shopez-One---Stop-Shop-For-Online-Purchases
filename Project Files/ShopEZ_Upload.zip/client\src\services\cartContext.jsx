import { createContext, useContext, useState, useEffect } from 'react';
import api from './api';
import { useAuth } from './authContext';

const CartContext = createContext();

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const { user } = useAuth(); // Depend on auth state

  // Refresh cart from server whenever the user changes (login/logout)
  useEffect(() => {
    if (user) {
      fetchCart();
    } else {
      setCartItems([]);
    }
  }, [user]);

  const fetchCart = async () => {
    try {
      const { data } = await api.get('/cart');
      if (data && data.success) {
        // Map backend structure { product: { _id, name... }, quantity } 
        // to frontend structure { id, name..., quantity }
        const mappedItems = data.data.items.map(item => ({
          ...item.product,
          id: item.product._id, // map Mongo _id to id for frontend logic
          quantity: item.quantity
        }));
        setCartItems(mappedItems);
      }
    } catch (error) {
      console.error('Failed to fetch cart', error);
      // Fallback: clear cart on error
      setCartItems([]);
    }
  };

  const addToCart = async (product, quantity = 1) => {
    if (!user) {
      alert("Please login to add items to the cart.");
      return;
    }

    try {
      // Optimistic update
      setCartItems((prevItems) => {
        const existingItem = prevItems.find((item) => item.id === product.id);
        if (existingItem) {
          return prevItems.map((item) =>
            item.id === product.id
              ? { ...item, quantity: item.quantity + quantity }
              : item
          );
        }
        return [...prevItems, { ...product, quantity }];
      });

      // Send to server
      await api.post('/cart/add', { productId: product.id || product._id, quantity });

      // Optionally trigger re-fetch to ensure sync
      // await fetchCart();
    } catch (error) {
      console.error('Failed to add to cart', error);
      fetchCart(); // Revert optimistic UI on error
    }
  };

  const removeFromCart = async (productId) => {
    if (!user) return;

    try {
      // Optimistic update
      setCartItems((prevItems) => prevItems.filter((item) => item.id !== productId));

      // Send to server
      await api.delete(`/cart/remove/${productId}`);
    } catch (error) {
      console.error('Failed to remove from cart', error);
      fetchCart(); // Revert optimistic UI on error
    }
  };

  const updateQuantity = async (productId, quantity) => {
    if (!user) return;

    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }

    try {
      // Optimistic update
      setCartItems((prevItems) =>
        prevItems.map((item) =>
          item.id === productId ? { ...item, quantity } : item
        )
      );

      // Send to server
      await api.put('/cart/update', { productId, quantity });
    } catch (error) {
      console.error('Failed to update cart quantity', error);
      fetchCart(); // Revert on failure
    }
  };

  const clearCart = async () => {
    if (!user) return;

    // In a real app we might just delete all or the cart document entirely.
    // For now, removing each locally or adding a clear endpoint. We can build a clear endpoint or loop...
    try {
      setCartItems([]);
      // We don't have a clear endpoint yet, so just clear locally for now
      // Alternatively, we could create an explicit DELETE /cart but not requested
      for (const item of cartItems) {
        await api.delete(`/cart/remove/${item.id}`);
      }
    } catch (error) {
      console.error('Failed to clear cart', error);
    }
  };

  const getCartTotal = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  const getCartCount = () => {
    return cartItems.reduce((count, item) => count + item.quantity, 0);
  };

  const value = {
    cartItems,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    getCartTotal,
    getCartCount,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};
